(() => {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const S = { ed: 'bedrock', inst: { java: [], bedrock: [] }, ver: null };
let tt;
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), 4500); }
const call = async (c, ...a) => { try { return await api.invoke(c, ...a); } catch (e) { const m = String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''); if (!/cancelled/.test(m)) toast(m); throw e; } };
const PLAY = '<svg viewBox="0 0 24 24"><path d="M7 4l14 8-14 8z"/></svg>';
const CUBE = { java: '<svg viewBox="0 0 64 64"><polygon points="32,5 59,20 32,35 5,20" fill="#5fa831"/><polygon points="5,20 32,35 32,61 5,46" fill="#80562f"/><polygon points="59,20 32,35 32,61 59,46" fill="#5e3f23"/></svg>',
  bedrock: '<svg viewBox="0 0 64 64"><polygon points="32,5 59,20 32,35 5,20" fill="#4a6b3a"/><polygon points="5,20 32,35 32,61 5,46" fill="#4b4f57"/><polygon points="59,20 32,35 32,61 59,46" fill="#363a41"/><circle cx="20" cy="42" r="3" fill="#3b82f6"/></svg>' };

// ---------- navigation (smooth page transitions)
const PAGES = { home: home, versions: versions, packs: packLibrary, accounts: accounts, servers: servers, settings: settings, instance: instanceSettings };
let cur = '';
async function go(p) {
  if (p === cur) return; cur = p;
  $$('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.page === p));
  const v = $('#view'); v.style.opacity = 0; v.style.transition = 'opacity .12s'; await sleep(120);
  v.innerHTML = ''; v.classList.remove('in'); void v.offsetWidth; v.classList.add('in'); v.style.opacity = 1;
  try { await PAGES[p](v); } catch (e) { v.innerHTML = `<div class="pad"><div class="empty">${esc(e.message)}</div></div>`; }
}
$$('.nav-btn').forEach(b => b.onclick = () => go(b.dataset.page));
$('#pill').onclick = () => go('accounts');
$$('[data-win]').forEach(b => b.onclick = () => api.invoke('win', b.dataset.win));
$('#logbtn').onclick = () => $('#log').classList.toggle('show');

// ---------- status / events
api.on('progress', p => { $('#status').textContent = p.text; $('#bar').style.width = (p.p * 100) + '%'; if (!p.p) setTimeout(() => $('#bar').style.width = 0, 800); });
api.on('log', t => { const l = $('#log'); l.textContent += t; l.scrollTop = l.scrollHeight; });
api.on('exit', e => { $('#status').textContent = `Game closed (code ${e.code})`; });
api.on('instance-changed', e => { if(cur==='home'&&S.ed===e.edition)draw(); });

// keyboard focus safety net for frameless windows
document.addEventListener('pointerdown', e => { if (e.target.closest('input,select')) api.invoke('win', 'focus'); }, true);
api.on('msdevice', d => { const c = $('#mcode'); if (c) { c.textContent = d.code; $('#mst').textContent = 'Enter this code on ' + d.uri + ' (the page opens automatically). Waiting...'; } });
async function profile() {
  const { accounts: a, active } = await call('acc:list'), acc = a.find(x => x.id === active);
  $('#pname').textContent = acc ? acc.name : 'No account'; $('#ava').textContent = acc ? acc.name[0].toUpperCase() : '?';
  $('#pstat').textContent = acc ? (acc.type === 'microsoft' ? 'Online' : 'Offline') + ' (Java) | Bedrock: game account' : 'Add a Java account';
}

// ---------- HOME
async function home(v) {
  v.innerHTML = `<div class="tabs"><button data-ed="java"><b>JAVA</b> EDITION</button><button data-ed="bedrock"><b>BEDROCK</b> EDITION</button><i class="ind"></i></div>
  <div class="pad"><h2 class="h2" id="h2"></h2><div class="grid" id="grid"></div><div class="center"><button class="btn big" id="new"></button></div></div>`;
  $$('.tabs button', v).forEach(b => b.onclick = () => setEd(b.dataset.ed));
  $('#new').onclick = openNew;
  $('#grid').onclick = onCard;
  await setEd(S.ed);
}
async function setEd(ed) {
  S.ed = ed; document.body.dataset.edition = ed;
  $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.ed === ed));
  $('.ind').style.transform = ed === 'java' ? 'translateX(0)' : 'translateX(100%)';
  $('#h2').innerHTML = `<span>${ed.toUpperCase()} EDITION</span> INSTANCES`;
  $('#new').textContent = `+ NEW ${ed.toUpperCase()} INSTANCE`;
  await draw();
}
async function draw() {
  const ed = S.ed; S.inst[ed] = await call('inst:list', ed);
  if (ed !== S.ed) return;
  $('#grid').innerHTML = S.inst[ed].map(card).join('') || '<div class="empty">No instances yet. Create the first one below.</div>';
}
function card(i, n) {
  const s = i.stats, l1 = i.edition === 'java' ? `Mods: ${s.mods} · Packs: ${s.resourcepacks} · Shaders: ${s.shaders}` : `Worlds: ${s.worlds}`, l2 = i.edition === 'java' ? `Worlds: ${s.worlds}` : `Add-on Packs: ${s.packs}`;
  return `<article class="card" data-id="${esc(i.id)}" style="--d:${n * 70}ms"><div class="accent"></div><h3>${esc(i.name)}</h3>
  <div class="crow"><div class="cico">${CUBE[i.edition]}</div><div class="meta">Version ${esc(i.version || '-')}<br>${l1} &nbsp;|&nbsp; ${l2}</div>
  <button class="play" data-act="play" aria-label="Play">${PLAY}</button></div>
  <div class="tools"><button data-act="settings">Instance settings</button><button data-act="clone">Duplicate empty</button><button data-act="folder">Open folder</button><button data-act="del" class="del">Delete</button></div></article>`;
}
async function onCard(e) {
  const b = e.target.closest('[data-act]');
  if (!b) { const c = e.target.closest('.card'); if (c) call('inst:open-window',S.ed,c.dataset.id); return; }
  const id = b.closest('.card').dataset.id, ed = S.ed;
  if (b.dataset.act === 'settings') call('inst:open-window',ed,id);
  if (b.dataset.act === 'clone') { const m=modal(`<h3>Duplicate instance</h3><p class="hint">A new empty instance will use the same Minecraft version and loader.</p><input id="cloneName" maxlength="40" value="${esc(S.inst[ed].find(x=>x.id===id)?.name+' copy')}"/><div class="actions"><button class="btn ghost" data-close>Cancel</button><button class="btn" id="cloneOk">Create copy</button></div>`);$('#cloneOk',m).onclick=async()=>{try{await call('inst:clone',ed,id,$('#cloneName',m).value);close(m);draw();}catch{}}; }
  if (b.dataset.act === 'folder') call('inst:folder', ed, id);
  if (b.dataset.act === 'del') {
    const m = modal(`<h3>Delete instance?</h3><p style="color:var(--dim)">Its folder (worlds, mods, settings) will be removed permanently.</p><div class="actions"><button class="btn ghost" data-close>Cancel</button><button class="btn danger" id="ok">Delete</button></div>`);
    $('#ok', m).onclick = async () => { close(m); await call('inst:delete', ed, id); draw(); };
  }
  if (b.dataset.act === 'play') {
    b.classList.add('busy'); $('#status').textContent = 'Starting...';
    try { await call('inst:play', ed, id); $('#status').textContent = 'Launched'; draw(); } catch {} finally { b.classList.remove('busy'); }
  }
}
async function instanceSettings(v) {
  const sel = S.selected; if (!sel) { cur = ''; return go('home'); }
  const chosen=new Map();
  const d = await call('inst:details', sel.edition, sel.id), i = d.instance, java = sel.edition === 'java';
  let contentOffset=0, contentTotal=0, contentQuery='', contentProvider='';
  const sections=java?['settings','mods','resourcepacks','shaderpacks']:['settings','resourcepacks','behaviorpacks'];
  let active=sections.includes(S.instanceSection)?S.instanceSection:'settings'; S.instanceSection=active;
  const contentKind=!java?(active==='behaviorpacks'?'behaviorpacks':'resourcepacks'):active==='resourcepacks'?'resourcepacks':active==='shaderpacks'?'shaderpacks':'mods';
  const bedrockFolderSection=(title,key,help)=>{const items=d.folders[key]?.files||[];return section(`${title} (${items.length})`,`<button class="btn" id="addBedrockPacks">Add pack files</button><p class="hint">${help}</p><div class="filelist">${items.map(x=>`<div class="file-row installed-file"><div class="installed-file-name"><b>${esc(x.name)}</b><small>${x.directory?'Pack folder':'Pack file'}</small></div><button class="chip" data-delete="${key}" data-file="${esc(x.name)}">Remove</button></div>`).join('')||'<div class="empty">Nothing here yet</div>'}</div>`,key);};
  const section = (title, body, key) => `<section class="iset"><div class="iset-head"><h3>${title}</h3>${key ? `<button class="btn ghost" data-open="${key}">Open folder</button>` : ''}</div>${body}</section>`;
  const folderSection = (title, key, help) => { const f=d.folders[key],items=f?.files||[]; return section(`${title} (${items.filter(x=>!x.directory&&!x.name.endsWith('.disabled')).length})`, `<p class="hint">${help}</p><div class="filelist">${items.map(x=>{const disabled=x.name.endsWith('.disabled'),meta=(d.installedContent||[]).find(y=>y.kind===key&&y.name===x.name.replace(/\.disabled$/,''));return x.directory?`<div class="file-row">▰ ${esc(x.name)}</div>`:`<div class="file-row installed-file">${meta?.icon?`<img src="${esc(meta.icon)}" alt="">`:''}<div class="installed-file-name"><b>${esc(meta?.title||x.name.replace(/\.disabled$/,''))}</b><small>${esc(x.name)}</small></div><button class="chip" data-toggle="${key}" data-file="${esc(x.name)}">${disabled?'Enable':'Disable'}</button><button class="chip" data-delete="${key}" data-file="${esc(x.name)}">Remove</button></div>`;}).join('')||'<div class="empty">Nothing here yet</div>'}</div>`,key); };
  const catalog=section(active==='mods'?'Find compatible mods':active==='resourcepacks'?'Find texture packs':active==='shaderpacks'?'Find shaders':'Find Bedrock add-ons',`<div class="content-search"><select id="contentSource">${java?'<option value="modrinth">Modrinth</option>':''}<option value="curseforge">CurseForge</option>${!java?'<option value="mcpeaddons">MCPE Addons</option>':''}</select><input id="contentQuery" placeholder="Search ${active==='mods'?'mods':active==='resourcepacks'?'texture packs':active==='shaderpacks'?'shaders':'add-ons'}"><button class="btn" id="contentSearch">Search</button></div><p class="hint">Filtered for Minecraft ${esc(i.version)}${java?` · ${esc(i.version.startsWith('fabric-loader-')?'Fabric':i.version.includes('-forge-')?'Forge':'Vanilla')}`:''}</p><div id="contentResults" class="content-results"><div class="empty">Search or browse popular items.</div></div>`);
  const tabs=java?[['settings','Settings'],['mods',`Mods (${d.folders.mods?.files.filter(x=>!x.directory&&!x.name.endsWith('.disabled')).length||0})`],['resourcepacks',`Texture packs (${d.folders.resourcepacks?.files.filter(x=>!x.directory&&!x.name.endsWith('.disabled')).length||0})`],['shaderpacks',`Shaders (${d.folders.shaderpacks?.files.filter(x=>!x.directory&&!x.name.endsWith('.disabled')).length||0})`]]:[['settings','Settings'],['resourcepacks','Resource packs'],['behaviorpacks','Add-ons']];
  const instanceControls=section('Instance',`<p class="hint">${java?'Java':'Bedrock'} · ${esc(i.version||'Installed')} · ${esc(i.id)}</p><div class="form"><button class="btn" id="launchInstance">Launch game</button><button class="btn danger" id="stopInstance">Emergency stop</button><button class="btn ghost" data-instance-folder>Open instance folder</button>${java?'<button class="btn ghost" id="importJavaPack">Import Java modpack</button>':'<button class="btn ghost" id="importBedrockPacks">Import Bedrock packs</button>'}</div>${java?'<p class="hint">Imports Modrinth .mrpack and CurseForge .zip archives for the same Minecraft version. The pack loader is installed automatically. Files with matching names are replaced; other existing files remain.</p>':''}<p class="hint">Emergency stop forcibly closes the game. Unsaved progress may be lost.</p>`);
  const panel=active==='settings'
    ? (java
      ? instanceControls + section('Performance',`<div class="set"><label>Minimum memory (MB)<input id="ramMin" type="number" min="256" max="65536" value="${d.settings.ramMin||512}"></label><label>Maximum memory (MB)<input id="ramMax" type="number" min="256" max="65536" value="${d.settings.ramMax||4096}"></label><label class="full">Garbage collector<select id="gc"><option value="default">Java default</option><option value="g1gc" ${d.settings.gc==='g1gc'?'selected':''}>G1GC</option><option value="zgc" ${d.settings.gc==='zgc'?'selected':''}>ZGC</option></select></label></div><div class="form"><button class="btn" id="saveInstance">Save settings</button></div>`)
        + section('Logs',`<pre class="log-view">${esc(d.logs||'No logs yet.')}</pre>`)
      : instanceControls + section('Instance options',`<p class="hint">Minecraft Bedrock manages memory and garbage collection. Packs and worlds are kept in this instance's isolated game folder.</p><p class="hint">Resource packs: ${d.folders.resourcepacks?.files.length||0} · Behavior packs: ${d.folders.behaviorpacks?.files.length||0}</p>`)
        + section('Logs',`<pre class="log-view">${esc(d.logs||'No logs yet.')}</pre>`))
    : active==='mods'?catalog+folderSection('Installed mods','mods','Downloaded mods for this instance.')
    : active==='resourcepacks'?(java?catalog:'')+(java?folderSection('Installed texture packs','resourcepacks','Downloaded texture packs.'):bedrockFolderSection('Installed resource packs','resourcepacks','Select one or more .mcpack or .mcaddon files. The launcher reads each manifest and places resource packs here.'))
    : active==='shaderpacks'?catalog+folderSection('Installed shaders','shaderpacks','Downloaded shader packs.')
    : bedrockFolderSection('Installed add-ons','behaviorpacks','Select one or more .mcpack or .mcaddon files. The launcher reads each manifest and places behavior packs and scripts here.');
  v.innerHTML=`<div class="pad"><div class="iset-head"><div><button class="chip" id="back">← Instances</button><h2 class="h2" style="margin-top:14px"><span>${esc(i.name)}</span></h2><div class="instance-sub">${java?'JAVA':'BEDROCK'} · ${esc(i.version)}</div></div></div><div class="instance-shell"><aside class="instance-nav">${tabs.map(([key,label])=>`<button class="instance-nav-btn ${active===key?'active':''}" data-section="${key}">${label}</button>`).join('')}</aside><div class="instance-pane">${panel}</div></div></div>`;
  $('#back',v).onclick=()=>{if(S.instanceWindow)api.invoke('win:self-close');else go('home');};
  const sourceSelect=$('#contentSource',v);
  sourceSelect?.querySelector('option[value="curseforge"]')?.toggleAttribute('disabled',java&&active!=='mods');
  if(sourceSelect&&java&&active!=='mods')sourceSelect.value='modrinth';
  if(sourceSelect&&!java)sourceSelect.value='mcpeaddons';
  $('#saveInstance',v)?.addEventListener('click',async()=>{try{await call('inst:settings',sel.edition,sel.id,{ramMin:$('#ramMin',v).value,ramMax:$('#ramMax',v).value,gc:$('#gc',v).value});toast('Instance settings saved');}catch{}});
  v.onclick=async e=>{
    if(e.target.closest('#importJavaPack')){const button=$('#importJavaPack',v);button.disabled=true;button.textContent='Importing…';try{const result=await call('packs:import',sel.id);if(result.imported||result.name){toast(`Imported ${result.name||'Java modpack'}${result.skipped?` · ${result.skipped} optional file(s) skipped`:''}`);cur='';await go('instance');}}catch(error){toast(error.message||'Could not import Java modpack');}finally{if(button.isConnected){button.disabled=false;button.textContent='Import Java modpack';}}return;}
    if(e.target.closest('#addBedrockPacks,#importBedrockPacks')){const button=e.target.closest('#addBedrockPacks,#importBedrockPacks');button.disabled=true;button.textContent='Choose files…';try{const result=await call('content:import',sel.edition,sel.id);if(result.imported.length){cur='';await go('instance');}const messages=[];if(result.imported.length)messages.push(`Added ${result.imported.length} pack(s)`);if(result.errors.length)messages.push(result.errors.map(x=>`${x.file}: ${x.message}`).join(' · '));if(messages.length)toast(messages.join(' — '));}catch(error){toast(error.message||'Could not add pack files');}finally{if(button.isConnected){button.disabled=false;button.textContent=button.id==='importBedrockPacks'?'Import Bedrock packs':'Add pack files';}}return;}
    if(e.target.closest('#launchInstance')){const button=$('#launchInstance',v);button.disabled=true;button.textContent='Starting…';$('#status').textContent='Starting game…';try{await call('inst:play',sel.edition,sel.id);$('#status').textContent='Game launched';toast('Game launched');}catch{}finally{button.disabled=false;button.textContent='Launch game';}return;}
    if(e.target.closest('#stopInstance')){const button=$('#stopInstance',v);button.disabled=true;button.textContent='Stopping…';try{const result=await call('inst:stop',sel.edition,sel.id);toast(result.stopped?'Game force-stopped.':result.message);$('#status').textContent=result.stopped?'Game force-stopped':'Game is not running';}catch{}finally{button.disabled=false;button.textContent='Emergency stop';}return;}
    if(e.target.closest('[data-instance-folder]')){await call('inst:folder',sel.edition,sel.id);return;}
    const sectionTab=e.target.closest('[data-section]');if(sectionTab){S.instanceSection=sectionTab.dataset.section;cur='';go('instance');return;}
    const folder=e.target.closest('[data-open]'); if(folder){await call('inst:open-folder',sel.edition,sel.id,folder.dataset.open);return;}
    const manager=e.target.closest('[data-toggle],[data-delete]');if(manager){try{const isToggle=!!manager.dataset.toggle,kind=manager.dataset.toggle||manager.dataset.delete,wasDisabled=manager.dataset.file.endsWith('.disabled'),result=await call('content:manage',sel.edition,sel.id,isToggle?'toggle':'delete',kind,manager.dataset.file),row=manager.closest('.file-row'),heading=manager.closest('.iset').querySelector('h3');if(isToggle){const off=result.disabled;row.querySelector('.installed-file-name small').textContent=result.name;row.querySelector('[data-toggle]').dataset.file=result.name;row.querySelector('[data-toggle]').textContent=off?'Enable':'Disable';row.querySelector('[data-delete]').dataset.file=result.name;const m=heading.textContent.match(/^(.*) \((\d+)\)$/);if(m)heading.textContent=`${m[1]} (${Math.max(0,Number(m[2])+(off?-1:1))})`;}else{row.remove();if(!wasDisabled){const m=heading.textContent.match(/^(.*) \((\d+)\)$/);if(m)heading.textContent=`${m[1]} (${Math.max(0,Number(m[2])-1)})`;}for(const item of result.removed||[]){const cb=v.querySelector(`[data-pick="${CSS.escape(item.projectId)}"]`);if(cb){cb.disabled=false;cb.closest('.pick-card').querySelector('.badge')?.remove();}}}toast(isToggle?(result.disabled?'Disabled':'Enabled'):'Removed');}catch{}return;}
    if(e.target.closest('#contentSearch') || (e.target.id==='contentQuery'&&e.key==='Enter')) {
      const provider=$('#contentSource',v).value, q=$('#contentQuery',v).value.trim(), box=$('#contentResults',v), btn=$('#contentSearch',v);
      btn.disabled=true;btn.textContent=q?'Searching…':'Loading popular…';box.innerHTML='<div class="empty">Finding popular compatible projects…</div>';
      try { chosen.clear();contentOffset=30;contentQuery=q;contentProvider=provider;const out=await call('content:search',sel.edition,sel.id,provider,q,contentKind,0);contentTotal=out.total||0;const cards=out.results.map(x=>`<article class="content-card"><label class="pick-card"><input type="checkbox" data-pick="${esc(x.id)}" data-source="${provider}" data-kind="${contentKind}" data-title="${esc(x.title)}" data-icon="${esc(x.icon||'')}" ${x.installed?'disabled':''}><div class="content-title">${x.icon?`<img src="${esc(x.icon)}" alt="">`:''}<div><b>${esc(x.title)} ${x.installed?'<span class="badge">Installed</span>':''}</b><small>${esc(x.author||'')} · ${Number(x.downloads||0).toLocaleString()} downloads</small></div></div></label><p>${esc(x.description||'')}</p></article>`).join('')||'<div class="empty">No compatible projects found.</div>';box.innerHTML=`<div class="bulk-bar"><span id="pickCount">0 selected</span><button class="btn" id="installSelected" disabled>Download selected</button></div>`+cards+(contentTotal>contentOffset?'<button class="btn load-more" id="contentMore">Load more</button>':''); }
      catch(e){box.innerHTML=`<div class="empty">Search failed: ${esc(e.message||'connection error')}</div>`;} finally{btn.disabled=false;btn.textContent='Search';}
      return;
    }
    const pick=e.target.closest('[data-pick]');if(pick){if(pick.checked)chosen.set(pick.dataset.pick,{source:pick.dataset.source,kind:pick.dataset.kind,title:pick.dataset.title,icon:pick.dataset.icon});else chosen.delete(pick.dataset.pick);const count=$('#pickCount',v),button=$('#installSelected',v);if(count)count.textContent=`${chosen.size} selected`;if(button)button.disabled=!chosen.size;return;}
    if(e.target.closest('#contentMore')){const b=$('#contentMore',v);b.disabled=true;b.textContent='Loading…';try{const out=await call('content:search',sel.edition,sel.id,contentProvider,contentQuery,contentKind,contentOffset);contentOffset+=30;const html=out.results.map(x=>`<article class="content-card"><label class="pick-card"><input type="checkbox" data-pick="${esc(x.id)}" data-source="${contentProvider}" data-kind="${contentKind}" data-title="${esc(x.title)}" data-icon="${esc(x.icon||'')}" ${x.installed?'disabled':''}><div class="content-title">${x.icon?`<img src="${esc(x.icon)}" alt="">`:''}<div><b>${esc(x.title)} ${x.installed?'<span class="badge">Installed</span>':''}</b><small>${esc(x.author||'')} · ${Number(x.downloads||0).toLocaleString()} downloads</small></div></div></label><p>${esc(x.description||'')}</p></article>`).join('');b.insertAdjacentHTML('beforebegin',html);if(contentOffset>=contentTotal)b.remove();else{b.disabled=false;b.textContent='Load more';}}catch{b.disabled=false;b.textContent='Retry';}return;}
    if(e.target.closest('#installSelected')){const button=$('#installSelected',v);button.disabled=true;button.textContent='Downloading…';let count=0;try{for(const [pid,data]of chosen){$('#status').textContent=`Installing ${count+1}/${chosen.size}…`;const vv=await call('content:versions',sel.edition,sel.id,data.source,pid,data.kind),ver=vv[0],file=ver?.files?.find(x=>x.primary)||ver?.files?.[0];if(!file?.url)throw new Error(`No compatible file for ${pid}`);await call('content:install',sel.edition,sel.id,data.source,pid,file.url,file.name,data.kind,ver.id,{title:data.title,icon:data.icon});count++;}toast(`Installed ${count} selected item(s)`);cur='';await go('instance');}catch{button.disabled=false;button.textContent=`Retry (${count}/${chosen.size})`;}}
  };
  if($('#contentSearch',v)){ $('#contentQuery',v).addEventListener('keydown',e=>{if(e.key==='Enter')$('#contentSearch',v).click();});$('#contentSource',v).addEventListener('change',()=>$('#contentSearch',v).click());$('#contentSearch',v).click();}
}
function modal(html) {
  const m = document.createElement('div'); m.className = 'mbg'; m.innerHTML = `<div class="modal">${html}</div>`; document.body.append(m);
  m.onclick = e => { if (e.target === m || e.target.dataset.close !== undefined) close(m); };
  $('input', m)?.focus(); return m;
}
const close = m => { m.style.opacity = 0; m.style.transition = 'opacity .15s'; setTimeout(() => m.remove(), 150); };
async function openNew() {
  const ed = S.ed; let f;
  if (ed === 'java') { S.ver ??= await call('versions:list'); S.loaders ??= await call('loaders:list'); f = `<label>Game version<select id="mv">${S.ver.versions.filter(x => x.type === 'release').map(x => `<option>${esc(x.id)}</option>`).join('')}</select></label><label>Loader<select id="ml"><option value="vanilla">Vanilla</option><option value="fabric">Fabric</option><option value="forge">Forge</option></select></label><label id="loaderVerLabel" style="display:none">Loader version<select id="mlv"></select></label>`; }
  else f = `<label>Version label (optional - the game version is managed by Microsoft)</label><input id="mv" maxlength="20" placeholder="e.g. 1.21.30">`;
  const m = modal(`<h3>New ${ed} instance</h3><div><label>Name</label><input id="mn" maxlength="40"></div><div>${f}</div><small id="createStatus" class="hint" aria-live="polite"></small><div class="actions"><button class="btn ghost" data-close>Cancel</button><button class="btn" id="ok">Create</button></div>`);
  if (ed === 'java') {
    const refreshLoaderVersions = () => {
      const kind = $('#ml', m).value, game = $('#mv', m).value, label = $('#loaderVerLabel', m), select = $('#mlv', m);
      if (kind === 'vanilla') { label.style.display = 'none'; return; }
      label.style.display = '';
      const choices = kind === 'fabric' ? (S.loaders.fabric.find(x => x.game === game)?.loaders || []) : S.loaders.forge.filter(x => x.game === game).map(x => x.version);
      select.innerHTML = choices.map(x => `<option>${esc(x)}</option>`).join('');
      if (!choices.length) select.innerHTML = '<option value="">No compatible loader version</option>';
    };
    $('#ml', m).onchange = refreshLoaderVersions; $('#mv', m).onchange = refreshLoaderVersions; refreshLoaderVersions();
  }
  const ok = async () => {
    const button = $('#ok', m), status = $('#createStatus', m);
    if (button.disabled) return;
    button.disabled = true; button.textContent = 'Please wait…';
    try {
      let version = $('#mv', m).value; const kind = ed === 'java' ? $('#ml', m).value : 'vanilla';
      if (kind !== 'vanilla') {
        status.textContent = `Preparing Minecraft ${version} with ${kind}… This can take a few minutes.`;
        button.textContent = 'Installing…';
        version = await call('loaders:install', kind, version, $('#mlv', m).value);
      }
      await call('inst:create', { edition: ed, name: $('#mn', m).value, version });
      close(m); draw();
    } catch {
      button.disabled = false; button.textContent = 'Try again'; status.textContent = 'Could not finish setup. Check the message and log, then try again.';
    }
  };
  $('#ok', m).onclick = ok; $('#mn', m).addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
}

// ---------- VERSIONS (Java)
async function versions(v) {
  v.innerHTML = '<div class="pad"><h2 class="h2"><span>VERSION</span> MANAGER (JAVA)</h2><div class="chips"><button class="chip on" data-t="release">Releases</button><button class="chip" data-t="snapshot">Snapshots</button><button class="chip" data-t="fabric">Fabric</button><button class="chip" data-t="forge">Forge</button></div><div class="list" id="vl"><div class="empty">Loading...</div></div></div>';
  S.ver = await call('versions:list'); S.loaders = await call('loaders:list'); let t = 'release';
  const draw = () => { const vanilla = t === 'release' || t === 'snapshot'; $('#vl').innerHTML = vanilla ? S.ver.versions.filter(x => x.type === t).slice(0, 120).map((x, n) => { const ins = S.ver.installed.includes(x.id);
    return `<div class="item" style="animation-delay:${Math.min(n, 12) * 30}ms"><div class="grow"><b>${esc(x.id)}</b><small>${x.date.slice(0, 10)}</small></div><button class="btn ${ins ? 'ghost' : ''}" data-id="${esc(x.id)}" ${ins ? 'disabled' : ''}>${ins ? 'Installed' : 'Install'}</button></div>`; }).join('') : (t === 'fabric' ? S.loaders.fabric.map(x => ({ game: x.game, versions: x.loaders, channel: 'Fabric' })) : S.loaders.forge.map(x => ({ game: x.game, versions: [x.version], channel: x.channel }))).map((x, n) => `<div class="item" style="animation-delay:${Math.min(n, 12) * 20}ms"><div class="grow"><b>${esc(x.game)} <span class="badge">${x.channel}</span></b><small>${x.versions.length} loader version${x.versions.length === 1 ? '' : 's'}</small></div><select data-loader="${t}" data-game="${esc(x.game)}" aria-label="${t} loader version">${x.versions.map(z => `<option>${esc(z)}</option>`).join('')}</select><button class="btn" data-install-loader="${t}" data-game="${esc(x.game)}">Install</button></div>`).join(''); };
  draw();
  $$('.chip', v).forEach(c => c.onclick = () => { t = c.dataset.t; $$('.chip', v).forEach(x => x.classList.toggle('on', x === c)); draw(); });
  $('#vl').onclick = async e => { const b = e.target.closest('button[data-id],button[data-install-loader]'); if (!b) return; b.disabled = true; b.textContent = '...';
    try { if (b.dataset.id) { await call('versions:install', b.dataset.id); S.ver.installed.push(b.dataset.id); } else { const sel = $(`select[data-game="${b.dataset.game}"]`, $('#vl')); await call('loaders:install', b.dataset.installLoader, b.dataset.game, sel.value); toast(`${b.dataset.installLoader} ${sel.value} for ${b.dataset.game} installed`); } } catch {} draw(); };
}

async function packLibrary(v) {
  v.innerHTML='<div class="pad"><h2 class="h2"><span>MODPACKS</span> MAINTENANCE</h2><div class="note">Modpack downloads are temporarily unavailable while technical maintenance is in progress. Please try again later.</div></div>';
  return;
  v.innerHTML=`<div class="pad"><h2 class="h2"><span>MODRINTH</span> MODPACKS</h2><div class="note">CurseForge support is coming soon. The application for API access has been submitted.</div><div class="content-search pack-filters"><input id="packQuery" placeholder="Search modpacks"><input id="packGame" placeholder="Minecraft version (e.g. 1.20.1)"><select id="packLoader"><option value="">Any loader</option><option value="fabric">Fabric</option><option value="forge">Forge</option><option value="vanilla">Vanilla</option></select><button id="packSearch" class="btn">Search</button></div><div class="hint">Modrinth packs are installed into a new, separate Java instance. Unsupported loaders are reported before changes are kept.</div><div id="packResults" class="content-results"><div class="empty">Search compatible modpacks.</div></div></div>`;
  let packOffset=0,packTotal=0;
  const search=async(more=false)=>{const btn=$('#packSearch',v),box=$('#packResults',v),game=$('#packGame',v).value.trim(),loader=$('#packLoader',v).value;if(!more){packOffset=0;box.innerHTML='<div class="empty">Finding packs…</div>';}const offset=packOffset;btn.disabled=true;btn.textContent=more?'Loading…':'Searching…';try{const data=await call('packs:search',$('#packQuery',v).value,game,loader,offset);packTotal=data.total||0;const cards=data.results.map(x=>`<article class="content-card">${x.icon?`<img class="pack-icon" src="${esc(x.icon)}" alt="" width="64" height="64" loading="lazy">`:''}<b>${esc(x.title)}</b><p>${esc(x.description||'')}</p><small>${Number(x.downloads||0).toLocaleString()} downloads</small><button class="btn" data-pack="${esc(x.id)}" data-name="${esc(x.title)}">Install pack</button></article>`).join('');if(more)$('#packMore',v)?.remove();box.insertAdjacentHTML(more?'beforeend':'afterbegin',cards||(!more?'<div class="empty">No matching packs.</div>':''));packOffset+=data.results.length;if(packOffset<packTotal)box.insertAdjacentHTML('beforeend','<button id="packMore" class="btn load-more">Load more</button>');}catch{}finally{btn.disabled=false;btn.textContent='Search';}};
  $('#packSearch',v).onclick=search;$('#packQuery',v).onkeydown=e=>{if(e.key==='Enter')search();};
  $('#packResults',v).onclick=async e=>{if(e.target.closest('#packMore')){await search(true);return;}const b=e.target.closest('[data-pack]');if(!b)return;b.disabled=true;b.textContent='Preparing…';try{const versions=await call('packs:versions',b.dataset.pack,$('#packGame',v).value.trim(),$('#packLoader',v).value);if(!versions.length)throw new Error('No pack version matches the selected game version and loader.');const installed=await call('packs:install',b.dataset.pack,versions[0].id,b.dataset.name);toast(`${installed.name} imported${installed.dependencies?` · ${installed.dependencies} required dependencies added`:''}`);cur='';await go('home');S.ed='java';document.body.dataset.edition='java';await draw();}catch{b.disabled=false;b.textContent='Install pack';}};
  try{S.ver??=await call('versions:list');$('#packGame',v).value=S.ver.latest.release||'';}catch{} await search();
}

// ---------- ACCOUNTS
async function accounts(v) {
  const { accounts: a, active } = await call('acc:list');
  v.innerHTML = `<div class="pad"><h2 class="h2"><span>JAVA</span> ACCOUNTS</h2>
  <div class="list">${a.map((x, n) => `<div class="item ${x.id === active ? 'act' : ''}" style="animation-delay:${n * 40}ms"><div class="grow"><b>${esc(x.name)}</b><span class="badge ${x.type}">${x.type === 'microsoft' ? 'Microsoft' : 'Offline'}</span><small>${esc(x.uuid)}</small></div>
    <button class="btn ghost" data-sel="${x.id}" ${x.id === active ? 'disabled' : ''}>${x.id === active ? 'Active' : 'Use'}</button><button class="btn ghost" data-rm="${x.id}">Remove</button></div>`).join('') || '<div class="empty">No Java accounts yet</div>'}</div>
  <div class="form"><input id="nick" maxlength="16" placeholder="Offline nickname (Latin letters, digits, _)"><button class="btn" id="add">Create offline</button><button class="btn ghost" id="ms">Sign in with Microsoft</button></div>
  <h2 class="h2"><span>BEDROCK</span> ACCOUNT</h2>
  <div class="note">Bedrock does not use launcher accounts. The launcher starts the real game and it signs in with its own Microsoft / Xbox account. Offline accounts are for Java only.</div></div>`;
  const refresh = async () => { cur = ''; await profile(); await go('accounts'); };
  $('#add', v).onclick = async () => { try { await call('acc:add', $('#nick', v).value); refresh(); } catch {} };
  $('#nick', v).addEventListener('keydown', e => { if (e.key === 'Enter') $('#add', v).click(); });
  $('#ms', v).onclick = async () => {
    const m = modal(`<h3>Sign in with Microsoft</h3><p style="color:var(--dim)" id="mst">Requesting code...</p><div class="code" id="mcode">...</div><div class="actions"><button class="btn ghost" id="mcopy">Copy code</button><button class="btn ghost" id="mcancel">Cancel</button></div>`);
    $('#mcopy', m).onclick = () => navigator.clipboard.writeText($('#mcode', m).textContent);
    $('#mcancel', m).onclick = () => { api.invoke('acc:ms-cancel'); close(m); };
    try { await call('acc:ms-login'); close(m); refresh(); } catch { close(m); }
  };
  v.onclick = async e => { const s = e.target.closest('[data-sel]'), r = e.target.closest('[data-rm]');
    if (s) { await call('acc:select', s.dataset.sel); refresh(); } if (r) { await call('acc:remove', r.dataset.rm); refresh(); } };
}

// ---------- SERVERS
async function servers(v) {
  const [list, ij, ib] = await Promise.all([call('srv:list'), call('inst:list', 'java'), call('inst:list', 'bedrock')]); S.inst.java = ij; S.inst.bedrock = ib;
  const opts = ed => S.inst[ed].map(i => `<option value="${esc(i.id)}">${esc(i.name)}</option>`).join('');
  v.innerHTML = `<div class="pad"><h2 class="h2"><span>SERVERS</span> / NETWORK</h2>
  <div class="list">${list.map((s, n) => `<div class="item" style="animation-delay:${n * 40}ms"><div class="grow"><b>${esc(s.name)}</b><small>${s.edition.toUpperCase()} | ${esc(s.host)}:${s.port}</small></div>
    <button class="btn" data-join="${s.id}">Join</button><button class="btn ghost" data-rm="${s.id}">Remove</button></div>`).join('') || '<div class="empty">No saved servers</div>'}</div>
  <div class="form"><input id="sn" placeholder="Name"><input id="sh" placeholder="Host / IP"><input id="sp" placeholder="Port" style="max-width:90px"></div>
  <div class="form"><select id="se"><option value="java">Java</option><option value="bedrock">Bedrock</option></select><select id="si">${opts('java')}</select><button class="btn" id="sa">Add server</button></div></div>`;
  const se = $('#se', v), si = $('#si', v); se.onchange = () => si.innerHTML = opts(se.value);
  $('#sa', v).onclick = async () => { try { await call('srv:add', { name: $('#sn', v).value, host: $('#sh', v).value, port: $('#sp', v).value, edition: se.value, instanceId: si.value }); cur = ''; go('servers'); } catch {} };
  v.onclick = async e => { const j = e.target.closest('[data-join]'), r = e.target.closest('[data-rm]');
    if (r) { await call('srv:remove', r.dataset.rm); cur = ''; go('servers'); }
    if (j) { const s = list.find(x => x.id === j.dataset.join); j.disabled = true; try { await call('inst:play', s.edition, s.instanceId, { host: s.host, port: s.port }); } catch {} j.disabled = false; } };
}

// ---------- SETTINGS
const JVM = {
  none: ['Default (no extra flags)', ''],
  g1: ['G1GC - balanced (recommended)', '-XX:+UnlockExperimentalVMOptions -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=50 -XX:+DisableExplicitGC -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:G1HeapRegionSize=16M -XX:+PerfDisableSharedMem'],
  aikar: ["Aikar's flags (G1GC, tuned)", '-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1'],
  zgc21: ['ZGC generational (Java 21-22)', '-XX:+UseZGC -XX:+ZGenerational'],
  zgc23: ['ZGC (Java 23+)', '-XX:+UseZGC'],
  shen: ['Shenandoah (OpenJDK / Temurin)', '-XX:+UseShenandoahGC'],
  par: ['Parallel GC (weak PCs)', '-XX:+UseParallelGC']
};
async function settings(v) {
  const [s, p] = await Promise.all([call('set:get'), call('paths')]);
  v.innerHTML = `<div class="pad"><h2 class="h2"><span>LAUNCHER</span> SETTINGS</h2><div class="set">
  <div class="full"><label>Java executable (empty = automatic: the launcher downloads the right Java itself)</label><input id="jp" placeholder="Automatic" value="${esc(s.javaPath === 'java' ? '' : s.javaPath)}"></div>
  <div><label>Min RAM (MB)</label><input id="rmin" type="number" value="${s.ramMin}"></div><div><label>Max RAM (MB)</label><input id="rmax" type="number" value="${s.ramMax}"></div>
  <div class="full"><label>Garbage collector preset</label><select id="jpre">${Object.entries(JVM).map(([k, [n]]) => `<option value="${k}" ${k === s.jvmPreset ? 'selected' : ''}>${esc(n)}</option>`).join('')}<option value="custom" ${s.jvmPreset === 'custom' ? 'selected' : ''}>Custom</option></select></div>
  <div class="full"><label>JVM arguments (editable)</label><input id="ja" value="${esc(s.jvmArgs)}"></div>
  <div class="full"><label>Microsoft Azure Client ID (needed for online Java accounts)</label><input id="ms" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" value="${esc(s.msClientId)}">
    <div class="hint">Register an app at portal.azure.com (App registrations, personal Microsoft accounts, enable "Allow public client flows"), then request Minecraft API access for it at aka.ms/AppRegInfo. Without Mojang's approval Microsoft login ends with a 403.</div></div>
  <div class="full"><label>CurseForge API key (required for in-app CurseForge search)</label><input id="cfkey" type="password" autocomplete="off" value="${esc(s.curseforgeApiKey||'')}"><div class="hint">Create a third-party developer key through CurseForge. The key is stored in the launcher's local settings.</div></div>
  <div class="full"><button class="btn" id="save">Save</button></div></div>
  <div class="paths">Java instances: <code>${esc(p.java)}</code><br>Bedrock instances: <code>${esc(p.bedrock)}</code><br>Config: <code>${esc(p.config)}</code></div></div>`;
  const pre = $('#jpre', v), ja = $('#ja', v);
  pre.onchange = () => { if (pre.value !== 'custom') ja.value = JVM[pre.value][1]; };
  ja.oninput = () => { pre.value = Object.entries(JVM).find(([, [, a]]) => a === ja.value.trim())?.[0] || 'custom'; };
  $('#save', v).onclick = async () => { try { await call('set:save', { javaPath: $('#jp').value, ramMin: $('#rmin').value, ramMax: $('#rmax').value, jvmArgs: ja.value, jvmPreset: pre.value, msClientId: $('#ms').value, curseforgeApiKey: $('#cfkey').value }); $('#status').textContent = 'Settings saved'; } catch {} };
}

profile();
const startup=new URLSearchParams(location.search),startupEdition=startup.get('instanceEdition'),startupId=startup.get('instanceId');
if(startupEdition&&startupId){S.selected={edition:startupEdition,id:startupId};S.ed=startupEdition;S.instanceWindow=true;document.body.classList.add('instance-window');document.body.dataset.edition=startupEdition;go('instance');}else go('home');
})();
