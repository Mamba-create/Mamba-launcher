(() => {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const S = { ed: 'bedrock', inst: { java: [], bedrock: [] }, ver: null };
let tt;
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), 4500); }
const call = async (c, ...a) => { try { return await api.invoke(c, ...a); } catch (e) { const m = String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''); if (!/cancelled/.test(m)) toast(m); throw e; } };
const PLAY = '<svg viewBox="0 0 24 24"><path d="M7 4l14 8-14 8z"/></svg>';
const CUBE = { java: '<svg viewBox="0 0 64 64"><polygon points="32,5 59,20 32,35 5,20" fill="#5fa831"/><polygon points="5,20 32,35 32,61 5,46" fill="#80562f"/><polygon points="59,20 32,35 32,61 59,46" fill="#5e3f23"/></svg>',
  bedrock: '<svg viewBox="0 0 64 64"><polygon points="32,5 59,20 32,35 5,20" fill="#4a6b3a"/><polygon points="5,20 32,35 32,61 5,46" fill="#4b4f57"/><polygon points="59,20 32,35 32,61 59,46" fill="#363a41"/><circle cx="20" cy="42" r="3" fill="#3b82f6"/></svg>' };

// ---------- navigation (smooth page transitions)
const PAGES = { home: home, versions: versions, accounts: accounts, servers: servers, settings: settings };
let cur = '';
async function go(p) {
  if (p === cur) return; cur = p;
  $$('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.page === p));
  const v = $('#view'); v.style.opacity = 0; v.style.transition = 'opacity .12s'; await sleep(120);
  v.innerHTML = ''; v.classList.remove('in'); void v.offsetWidth; v.classList.add('in'); v.style.opacity = 1;
  try { await PAGES[p](v); } catch (e) { v.innerHTML = `<div class="pad"><div class="empty">${esc(e.message)}</div></div>`; }
}
$$('.nav-btn').forEach(b => b.onclick = () => go(b.dataset.page));
$('#pill').onclick = () => go('accounts');
$$('[data-win]').forEach(b => b.onclick = () => api.invoke('win', b.dataset.win));
$('#logbtn').onclick = () => $('#log').classList.toggle('show');

// ---------- status / events
api.on('progress', p => { $('#status').textContent = p.text; $('#bar').style.width = (p.p * 100) + '%'; if (!p.p) setTimeout(() => $('#bar').style.width = 0, 800); });
api.on('log', t => { const l = $('#log'); l.textContent += t; l.scrollTop = l.scrollHeight; });
api.on('exit', e => { $('#status').textContent = `Game closed (code ${e.code})`; });

// keyboard focus safety net for frameless windows
document.addEventListener('pointerdown', e => { if (e.target.closest('input,select')) api.invoke('win', 'focus'); }, true);
api.on('msdevice', d => { const c = $('#mcode'); if (c) { c.textContent = d.code; $('#mst').textContent = 'Enter this code on ' + d.uri + ' (the page opens automatically). Waiting...'; } });
async function profile() {
  const { accounts: a, active } = await call('acc:list'), acc = a.find(x => x.id === active);
  $('#pname').textContent = acc ? acc.name : 'No account'; $('#ava').textContent = acc ? acc.name[0].toUpperCase() : '?';
  $('#pstat').textContent = acc ? (acc.type === 'microsoft' ? 'Online' : 'Offline') + ' (Java) | Bedrock: game account' : 'Add a Java account';
}

// ---------- HOME
async function home(v) {
  v.innerHTML = `<div class="tabs"><button data-ed="java"><b>JAVA</b> EDITION</button><button data-ed="bedrock"><b>BEDROCK</b> EDITION</button><i class="ind"></i></div>
  <div class="pad"><h2 class="h2" id="h2"></h2><div class="grid" id="grid"></div><div class="center"><button class="btn big" id="new"></button></div></div>`;
  $$('.tabs button', v).forEach(b => b.onclick = () => setEd(b.dataset.ed));
  $('#new').onclick = openNew;
  $('#grid').onclick = onCard;
  await setEd(S.ed);
}
async function setEd(ed) {
  S.ed = ed; document.body.dataset.edition = ed;
  $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.ed === ed));
  $('.ind').style.transform = ed === 'java' ? 'translateX(0)' : 'translateX(100%)';
  $('#h2').innerHTML = `<span>${ed.toUpperCase()} EDITION</span> INSTANCES`;
  $('#new').textContent = `+ NEW ${ed.toUpperCase()} INSTANCE`;
  await draw();
}
async function draw() {
  const ed = S.ed; S.inst[ed] = await call('inst:list', ed);
  if (ed !== S.ed) return;
  $('#grid').innerHTML = S.inst[ed].map(card).join('') || '<div class="empty">No instances yet. Create the first one below.</div>';
}
function card(i, n) {
  const s = i.stats, l1 = i.edition === 'java' ? `Mods: ${s.mods}` : `Worlds: ${s.worlds}`, l2 = i.edition === 'java' ? `Worlds: ${s.worlds}` : `Add-on Packs: ${s.packs}`;
  return `<article class="card" data-id="${esc(i.id)}" style="--d:${n * 70}ms"><div class="accent"></div><h3>${esc(i.name)}</h3>
  <div class="crow"><div class="cico">${CUBE[i.edition]}</div><div class="meta">Version ${esc(i.version || '-')}<br>${l1} &nbsp;|&nbsp; ${l2}</div>
  <button class="play" data-act="play" aria-label="Play">${PLAY}</button></div>
  <div class="tools"><button data-act="folder">Open folder</button><button data-act="del" class="del">Delete</button></div></article>`;
}
async function onCard(e) {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const id = b.closest('.card').dataset.id, ed = S.ed;
  if (b.dataset.act === 'folder') call('inst:folder', ed, id);
  if (b.dataset.act === 'del') {
    const m = modal(`<h3>Delete instance?</h3><p style="color:var(--dim)">Its folder (worlds, mods, settings) will be removed permanently.</p><div class="actions"><button class="btn ghost" data-close>Cancel</button><button class="btn danger" id="ok">Delete</button></div>`);
    $('#ok', m).onclick = async () => { close(m); await call('inst:delete', ed, id); draw(); };
  }
  if (b.dataset.act === 'play') {
    b.classList.add('busy'); $('#status').textContent = 'Starting...';
    try { await call('inst:play', ed, id); $('#status').textContent = 'Launched'; draw(); } catch {} finally { b.classList.remove('busy'); }
  }
}
function modal(html) {
  const m = document.createElement('div'); m.className = 'mbg'; m.innerHTML = `<div class="modal">${html}</div>`; document.body.append(m);
  m.onclick = e => { if (e.target === m || e.target.dataset.close !== undefined) close(m); };
  $('input', m)?.focus(); return m;
}
const close = m => { m.style.opacity = 0; m.style.transition = 'opacity .15s'; setTimeout(() => m.remove(), 150); };
async function openNew() {
  const ed = S.ed; let f;
  if (ed === 'java') { S.ver ??= await call('versions:list'); f = `<label>Game version<select id="mv">${S.ver.versions.filter(x => x.type === 'release').map(x => `<option>${esc(x.id)}</option>`).join('')}</select></label>`; }
  else f = `<label>Version label (optional - the game version is managed by Microsoft)</label><input id="mv" maxlength="20" placeholder="e.g. 1.21.30">`;
  const m = modal(`<h3>New ${ed} instance</h3><div><label>Name</label><input id="mn" maxlength="40"></div><div>${f}</div><div class="actions"><button class="btn ghost" data-close>Cancel</button><button class="btn" id="ok">Create</button></div>`);
  const ok = async () => { try { await call('inst:create', { edition: ed, name: $('#mn', m).value, version: $('#mv', m).value }); close(m); draw(); } catch {} };
  $('#ok', m).onclick = ok; $('#mn', m).addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
}

// ---------- VERSIONS (Java)
async function versions(v) {
  v.innerHTML = '<div class="pad"><h2 class="h2"><span>VERSION</span> MANAGER (JAVA)</h2><div class="chips"><button class="chip on" data-t="release">Releases</button><button class="chip" data-t="snapshot">Snapshots</button></div><div class="list" id="vl"><div class="empty">Loading...</div></div></div>';
  S.ver = await call('versions:list'); let t = 'release';
  const draw = () => { $('#vl').innerHTML = S.ver.versions.filter(x => x.type === t).slice(0, 120).map((x, n) => { const ins = S.ver.installed.includes(x.id);
    return `<div class="item" style="animation-delay:${Math.min(n, 12) * 30}ms"><div class="grow"><b>${esc(x.id)}</b><small>${x.date.slice(0, 10)}</small></div><button class="btn ${ins ? 'ghost' : ''}" data-id="${esc(x.id)}" ${ins ? 'disabled' : ''}>${ins ? 'Installed' : 'Install'}</button></div>`; }).join(''); };
  draw();
  $$('.chip', v).forEach(c => c.onclick = () => { t = c.dataset.t; $$('.chip', v).forEach(x => x.classList.toggle('on', x === c)); draw(); });
  $('#vl').onclick = async e => { const b = e.target.closest('button[data-id]'); if (!b) return; b.disabled = true; b.textContent = '...';
    try { await call('versions:install', b.dataset.id); S.ver.installed.push(b.dataset.id); } catch {} draw(); };
}

// ---------- ACCOUNTS
async function accounts(v) {
  const { accounts: a, active } = await call('acc:list');
  v.innerHTML = `<div class="pad"><h2 class="h2"><span>JAVA</span> ACCOUNTS</h2>
  <div class="list">${a.map((x, n) => `<div class="item ${x.id === active ? 'act' : ''}" style="animation-delay:${n * 40}ms"><div class="grow"><b>${esc(x.name)}</b><span class="badge ${x.type}">${x.type === 'microsoft' ? 'Microsoft' : 'Offline'}</span><small>${esc(x.uuid)}</small></div>
    <button class="btn ghost" data-sel="${x.id}" ${x.id === active ? 'disabled' : ''}>${x.id === active ? 'Active' : 'Use'}</button><button class="btn ghost" data-rm="${x.id}">Remove</button></div>`).join('') || '<div class="empty">No Java accounts yet</div>'}</div>
  <div class="form"><input id="nick" maxlength="16" placeholder="Offline nickname (Latin letters, digits, _)"><button class="btn" id="add">Create offline</button><button class="btn ghost" id="ms">Sign in with Microsoft</button></div>
  <h2 class="h2"><span>BEDROCK</span> ACCOUNT</h2>
  <div class="note">Bedrock does not use launcher accounts. The launcher starts the real game and it signs in with its own Microsoft / Xbox account. Offline accounts are for Java only.</div></div>`;
  const refresh = async () => { cur = ''; await profile(); await go('accounts'); };
  $('#add', v).onclick = async () => { try { await call('acc:add', $('#nick', v).value); refresh(); } catch {} };
  $('#nick', v).addEventListener('keydown', e => { if (e.key === 'Enter') $('#add', v).click(); });
  $('#ms', v).onclick = async () => {
    const m = modal(`<h3>Sign in with Microsoft</h3><p style="color:var(--dim)" id="mst">Requesting code...</p><div class="code" id="mcode">...</div><div class="actions"><button class="btn ghost" id="mcopy">Copy code</button><button class="btn ghost" id="mcancel">Cancel</button></div>`);
    $('#mcopy', m).onclick = () => navigator.clipboard.writeText($('#mcode', m).textContent);
    $('#mcancel', m).onclick = () => { api.invoke('acc:ms-cancel'); close(m); };
    try { await call('acc:ms-login'); close(m); refresh(); } catch { close(m); }
  };
  v.onclick = async e => { const s = e.target.closest('[data-sel]'), r = e.target.closest('[data-rm]');
    if (s) { await call('acc:select', s.dataset.sel); refresh(); } if (r) { await call('acc:remove', r.dataset.rm); refresh(); } };
}

// ---------- SERVERS
async function servers(v) {
  const [list, ij, ib] = await Promise.all([call('srv:list'), call('inst:list', 'java'), call('inst:list', 'bedrock')]); S.inst.java = ij; S.inst.bedrock = ib;
  const opts = ed => S.inst[ed].map(i => `<option value="${esc(i.id)}">${esc(i.name)}</option>`).join('');
  v.innerHTML = `<div class="pad"><h2 class="h2"><span>SERVERS</span> / NETWORK</h2>
  <div class="list">${list.map((s, n) => `<div class="item" style="animation-delay:${n * 40}ms"><div class="grow"><b>${esc(s.name)}</b><small>${s.edition.toUpperCase()} | ${esc(s.host)}:${s.port}</small></div>
    <button class="btn" data-join="${s.id}">Join</button><button class="btn ghost" data-rm="${s.id}">Remove</button></div>`).join('') || '<div class="empty">No saved servers</div>'}</div>
  <div class="form"><input id="sn" placeholder="Name"><input id="sh" placeholder="Host / IP"><input id="sp" placeholder="Port" style="max-width:90px"></div>
  <div class="form"><select id="se"><option value="java">Java</option><option value="bedrock">Bedrock</option></select><select id="si">${opts('java')}</select><button class="btn" id="sa">Add server</button></div></div>`;
  const se = $('#se', v), si = $('#si', v); se.onchange = () => si.innerHTML = opts(se.value);
  $('#sa', v).onclick = async () => { try { await call('srv:add', { name: $('#sn', v).value, host: $('#sh', v).value, port: $('#sp', v).value, edition: se.value, instanceId: si.value }); cur = ''; go('servers'); } catch {} };
  v.onclick = async e => { const j = e.target.closest('[data-join]'), r = e.target.closest('[data-rm]');
    if (r) { await call('srv:remove', r.dataset.rm); cur = ''; go('servers'); }
    if (j) { const s = list.find(x => x.id === j.dataset.join); j.disabled = true; try { await call('inst:play', s.edition, s.instanceId, { host: s.host, port: s.port }); } catch {} j.disabled = false; } };
}

// ---------- SETTINGS
const JVM = {
  none: ['Default (no extra flags)', ''],
  g1: ['G1GC - balanced (recommended)', '-XX:+UnlockExperimentalVMOptions -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=50 -XX:+DisableExplicitGC -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:G1HeapRegionSize=16M -XX:+PerfDisableSharedMem'],
  aikar: ["Aikar's flags (G1GC, tuned)", '-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1'],
  zgc21: ['ZGC generational (Java 21-22)', '-XX:+UseZGC -XX:+ZGenerational'],
  zgc23: ['ZGC (Java 23+)', '-XX:+UseZGC'],
  shen: ['Shenandoah (OpenJDK / Temurin)', '-XX:+UseShenandoahGC'],
  par: ['Parallel GC (weak PCs)', '-XX:+UseParallelGC']
};
async function settings(v) {
  const [s, p] = await Promise.all([call('set:get'), call('paths')]);
  v.innerHTML = `<div class="pad"><h2 class="h2"><span>LAUNCHER</span> SETTINGS</h2><div class="set">
  <div class="full"><label>Java executable (empty = automatic: the launcher downloads the right Java itself)</label><input id="jp" placeholder="Automatic" value="${esc(s.javaPath === 'java' ? '' : s.javaPath)}"></div>
  <div><label>Min RAM (MB)</label><input id="rmin" type="number" value="${s.ramMin}"></div><div><label>Max RAM (MB)</label><input id="rmax" type="number" value="${s.ramMax}"></div>
  <div class="full"><label>Garbage collector preset</label><select id="jpre">${Object.entries(JVM).map(([k, [n]]) => `<option value="${k}" ${k === s.jvmPreset ? 'selected' : ''}>${esc(n)}</option>`).join('')}<option value="custom" ${s.jvmPreset === 'custom' ? 'selected' : ''}>Custom</option></select></div>
  <div class="full"><label>JVM arguments (editable)</label><input id="ja" value="${esc(s.jvmArgs)}"></div>
  <div class="full"><label>Microsoft Azure Client ID (needed for online Java accounts)</label><input id="ms" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" value="${esc(s.msClientId)}">
    <div class="hint">Register an app at portal.azure.com (App registrations, personal Microsoft accounts, enable "Allow public client flows"), then request Minecraft API access for it at aka.ms/AppRegInfo. Without Mojang's approval Microsoft login ends with a 403.</div></div>
  <div class="full"><button class="btn" id="save">Save</button></div></div>
  <div class="paths">Java instances: <code>${esc(p.java)}</code><br>Bedrock instances: <code>${esc(p.bedrock)}</code><br>Config: <code>${esc(p.config)}</code></div></div>`;
  const pre = $('#jpre', v), ja = $('#ja', v);
  pre.onchange = () => { if (pre.value !== 'custom') ja.value = JVM[pre.value][1]; };
  ja.oninput = () => { pre.value = Object.entries(JVM).find(([, [, a]]) => a === ja.value.trim())?.[0] || 'custom'; };
  $('#save', v).onclick = async () => { try { await call('set:save', { javaPath: $('#jp').value, ramMin: $('#rmin').value, ramMax: $('#rmax').value, jvmArgs: ja.value, jvmPreset: pre.value, msClientId: $('#ms').value }); $('#status').textContent = 'Settings saved'; } catch {} };
}

profile(); go('home');
})();
