@echo off
cd /d "%~dp0"
if not exist node_modules\electron\dist\electron.exe (
  echo Run start.bat once first - it installs the dependencies.
  pause & exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([IO.Path]::Combine([Environment]::GetFolderPath('Desktop'),'Mamba Launcher.lnk')); $s.TargetPath='%~dp0node_modules\electron\dist\electron.exe'; $s.Arguments='\"%~dp0.\"'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0build\icon.ico'; $s.Save()"
echo Shortcut "Mamba Launcher" created on your desktop.
pause
