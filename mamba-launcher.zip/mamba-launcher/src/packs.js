const fs=require('fs'),path=require('path'),crypto=require('crypto'),AdmZip=require('adm-zip');
const {createInstance,instDir,gameDir}=require('./store');
const ROOT='https://api.modrinth.com/v2';
async function json(url){const r=await fetch(url,{headers:{'User-Agent':'MambaLauncher/1.0 (support@mamba.local)'}});if(!r.ok)throw new Error(`Modrinth request failed (${r.status})`);return r.json();}
async function search(query='',game='',loader='',offset=0){
 const facets=[['project_type:modpack']];if(game)facets.push([`versions:${game}`]);if(loader&&loader!=='vanilla')facets.push([`categories:${loader}`]);
 const u=new URL(`${ROOT}/search`);if(query)u.searchParams.set('query',query);u.searchParams.set('facets',JSON.stringify(facets));u.searchParams.set('limit','30');u.searchParams.set('offset',String(offset));u.searchParams.set('index','downloads');
 const r=await json(u);return {total:r.total_hits??0,results:r.hits.map(x=>({id:x.project_id,title:x.title,description:x.description,icon:x.icon_url,downloads:x.downloads,versions:x.versions,loaders:x.categories}))};
}
async function versions(projectId,game,loader){const all=await json(`${ROOT}/project/${encodeURIComponent(projectId)}/version`);return all.filter(v=>v.game_versions?.includes(game)&&(!loader||loader==='vanilla'||v.loaders?.includes(loader))).map(v=>({id:v.id,name:v.name||v.version_number,date:v.date_published}));}
async function install(projectId,versionId,name){
 const versions=await json(`${ROOT}/project/${encodeURIComponent(projectId)}/version`),v=versions.find(x=>x.id===versionId);if(!v)throw new Error('Pack version not found');
 const packFile=v.files.find(x=>x.primary)||v.files[0];if(!packFile)throw new Error('Pack download is missing');
 const response=await fetch(packFile.url);if(!response.ok)throw new Error(`Pack download failed (${response.status})`);const zip=Buffer.from(await response.arrayBuffer());if(zip.length>1024*1024*1024)throw new Error('Pack exceeds 1 GB limit');
 const archive=new AdmZip(zip),entry=archive.getEntry('modrinth.index.json');if(!entry)throw new Error('Invalid Modrinth pack: index is missing');const index=JSON.parse(entry.getData().toString('utf8'));
 const dep=index.dependencies||{},game=dep.minecraft;if(!game)throw new Error('Pack does not specify a Minecraft version');
 const loader=['fabric-loader','forge','neoforge','quilt-loader'].find(x=>dep[x]);if(loader==='neoforge'||loader==='quilt-loader')throw new Error(`This launcher does not support ${loader} packs yet`);
 const loaderId=loader==='fabric-loader'?'fabric':loader==='forge'?'forge':'vanilla';
 const inst=createInstance({edition:'java',name:name||index.name||'Modrinth Pack',version:game});
 try{
   if(loaderId!=='vanilla') await require('./java').installLoader(loaderId,game,dep[loader]);
   const targetVersion=loaderId==='vanilla'?game:(loaderId==='fabric'?`fabric-loader-${dep[loader]}-${game}`:`${game}-forge-${dep[loader]}`);
   inst.version=targetVersion;fs.writeFileSync(path.join(instDir('java',inst.id),'instance.json'),JSON.stringify(inst,null,2));
   const base=gameDir(inst),safe=(root,p)=>{const out=path.resolve(root,p);if(out!==root&&!out.startsWith(root+path.sep))throw new Error('Pack contains an unsafe file path');return out;};
   for(const item of index.files||[]){if(item.env?.client==='unsupported')continue;const rel=String(item.path||'').replace(/\\/g,'/');const dest=safe(base,rel);if(!dest.startsWith(base+path.sep))throw new Error('Unsafe pack file');
     let data=null;for(const url of item.downloads||[]){const r=await fetch(url);if(r.ok){data=Buffer.from(await r.arrayBuffer());break;}}
     if(!data){if(item.env?.client==='optional')continue;throw new Error(`Could not download ${path.basename(rel)}`);}
     const expected=item.fileSize||0;if(expected&&data.length!==expected)throw new Error(`File size mismatch for ${path.basename(rel)}`);
     const hash=item.hashes?.sha1;if(hash&&crypto.createHash('sha1').update(data).digest('hex')!==hash)throw new Error(`Checksum mismatch for ${path.basename(rel)}`);
     fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,data);
   }
   const includedVersions=new Set(),rootVersions=[];
   for(const item of (index.files||[]).filter(x=>/^mods\/.*\.jar$/i.test(String(x.path||'')))){
     const hash=item.hashes?.sha1;if(!hash)continue;
     try{const version=await json(`${ROOT}/version_file/${hash}?algorithm=sha1`);if(version.id){includedVersions.add(version.id);rootVersions.push(version);}}
     catch(error){if(!/\(404\)/.test(error.message||''))throw error;}
   }
   const visited=new Set();let dependencyCount=0;
   async function installRequired(version){
     if(!version?.id||visited.has(version.id))return;visited.add(version.id);
     for(const dependency of version.dependencies||[]){
       if(dependency.dependency_type!=='required')continue;
       let required;
       if(dependency.version_id)required=await json(`${ROOT}/version/${encodeURIComponent(dependency.version_id)}`);
       else if(dependency.project_id){const projectUrl=`${ROOT}/project/${encodeURIComponent(dependency.project_id)}/version`,u=new URL(projectUrl);u.searchParams.set('game_versions',JSON.stringify([game]));if(loaderId!=='vanilla')u.searchParams.set('loaders',JSON.stringify([loaderId]));let available=await json(u);if(!available.length){const all=await json(projectUrl),loaderMatches=x=>loaderId==='vanilla'||!x.loaders?.length||x.loaders.includes(loaderId),parts=String(game).split('.'),sameLine=x=>(x.game_versions||[]).some(g=>{const p=String(g).split('.');return p.length>=2&&parts.length>=2&&p[0]===parts[0]&&p[1]===parts[1];});available=all.filter(x=>loaderMatches(x)&&((x.game_versions||[]).includes(game)||sameLine(x)||!x.game_versions?.length));}required=available[0];}
       else throw new Error(`A required dependency of ${version.name||version.id} has no downloadable Modrinth version.`);
       if(!required)throw new Error(`No compatible required dependency version found for ${dependency.project_id||dependency.version_id} (${game}, ${loaderId}).`);
       const supportedGames=required.game_versions||[],supportedLoaders=required.loaders||[],parts=String(game).split('.'),sameLine=supportedGames.some(g=>{const p=String(g).split('.');return p.length>=2&&parts.length>=2&&p[0]===parts[0]&&p[1]===parts[1];});
       if((supportedGames.length&&!supportedGames.includes(game)&&!sameLine)||(loaderId!=='vanilla'&&supportedLoaders.length&&!supportedLoaders.includes(loaderId)))throw new Error(`Required dependency ${required.name||required.id} has no compatible version for ${game} / ${loaderId}.`);
       if(includedVersions.has(required.id))continue;
       await installRequired(required);
       const file=required.files?.find(x=>x.primary)||required.files?.[0];if(!file?.url)throw new Error(`Download file missing for required dependency ${required.name||required.id}.`);
       const response=await fetch(file.url);if(!response.ok)throw new Error(`Dependency download failed (${response.status}): ${file.filename}`);
       const data=Buffer.from(await response.arrayBuffer());if(data.length>300*1024*1024)throw new Error(`Required dependency is too large: ${file.filename}`);
       if(file.hashes?.sha1&&crypto.createHash('sha1').update(data).digest('hex')!==file.hashes.sha1)throw new Error(`Checksum mismatch for required dependency ${file.filename}.`);
       const dest=safe(base,path.posix.join('mods',path.basename(file.filename)));fs.mkdirSync(path.dirname(dest),{recursive:true});if(!fs.existsSync(dest))fs.writeFileSync(dest,data);
       includedVersions.add(required.id);dependencyCount++;
     }
   }
   for(const version of rootVersions)await installRequired(version);
   for(const e of archive.getEntries()){if(!e.entryName.startsWith('overrides/'))continue;const rel=e.entryName.slice('overrides/'.length);if(!rel)continue;const dest=safe(base,rel);if(e.isDirectory)fs.mkdirSync(dest,{recursive:true});else{fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,e.getData());}}
   return {id:inst.id,name:inst.name,version:inst.version,dependencies:dependencyCount};
 }catch(e){require('./store').deleteInstance('java',inst.id);throw e;}
}

function javaTarget(instance){
 const id=String(instance?.version||'');
 let m=id.match(/^fabric-loader-(.+)-(\d+\.\d+(?:\.\d+)?)$/);
 if(m)return {game:m[2],loader:'fabric',version:m[1]};
 m=id.match(/^(\d+\.\d+(?:\.\d+)?)-forge-(.+)$/);
 if(m)return {game:m[1],loader:'forge',version:m[2]};
 if(/^\d+\.\d+(?:\.\d+)?$/.test(id))return {game:id,loader:'vanilla',version:''};
 throw new Error('Cannot determine this instance Minecraft version or loader.');
}
function safePackPath(root,relative){
 const rel=String(relative||'').replace(/\\/g,'/');
 if(!rel||rel.startsWith('/')||/^[a-z]:/i.test(rel)||rel.split('/').some(part=>!part||part==='.'||part==='..'||/[<>:"|?*\x00-\x1f]/.test(part)||/[. ]$/.test(part)))throw new Error('The pack contains an unsafe file path.');
 const out=path.resolve(root,...rel.split('/'));
 if(!out.startsWith(path.resolve(root)+path.sep))throw new Error('The pack contains an unsafe file path.');
 return out;
}
async function importIntoInstance(id,filePaths,curseforgeKey=''){
 const {getInstance}=require('./store'),instance=getInstance('java',id);
 if(!instance)throw new Error('Java instance not found.');
 const target=javaTarget(instance),result={imported:0,skipped:0,name:''};
 for(const source of filePaths){
   const ext=path.extname(source).toLowerCase();if(!['.mrpack','.zip'].includes(ext))throw new Error('Choose a .mrpack or CurseForge .zip modpack.');
   const stat=fs.statSync(source);if(!stat.isFile()||stat.size>1024*1024*1024)throw new Error('Each modpack must be a file smaller than 1 GB.');
   const archive=new AdmZip(source),entries=archive.getEntries().filter(e=>!e.isDirectory);
   if(entries.length>15000)throw new Error('The modpack contains too many files.');
   let totalSize=0;for(const e of entries){totalSize+=e.header.size;if(e.header.size>1024*1024*1024||totalSize>2*1024*1024*1024)throw new Error('The unpacked modpack exceeds 2 GB.');}
   const byName=new Map(entries.map(e=>[e.entryName.replace(/\\/g,'/'),e]));
   const mrEntry=byName.get('modrinth.index.json');
   const cfEntry=byName.get('manifest.json')||[...byName].find(([p])=>/^[^/]+\/manifest\.json$/.test(p)&&!p.startsWith('overrides/'))?.[1];
   if(!mrEntry&&!cfEntry)throw new Error('This archive is not a supported Java modpack.');
   const stage=path.join(instDir('java',id),`.mamba-pack-import-${crypto.randomBytes(6).toString('hex')}`);
   let installedVersion=target.game;
   fs.mkdirSync(stage,{recursive:true});
   try{
     const unpack=(archivePrefix,stagePrefix='')=>{
       for(const [entryName,entry] of byName){
         if(!entryName.startsWith(archivePrefix))continue;
         const relative=entryName.slice(archivePrefix.length);if(!relative)continue;
         const out=safePackPath(stage,stagePrefix?path.posix.join(stagePrefix,relative):relative);
         fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,entry.getData());
       }
     };
     if(mrEntry){
       const index=JSON.parse(mrEntry.getData().toString('utf8')),deps=index.dependencies||{},game=String(deps.minecraft||'');
       if(!game)throw new Error('The Modrinth pack does not specify a Minecraft version.');
       const loaderKey=['fabric-loader','forge'].find(x=>deps[x]),loader=loaderKey==='fabric-loader'?'fabric':loaderKey||'vanilla';
       if(['neoforge','quilt-loader'].some(x=>deps[x]))throw new Error('This pack uses NeoForge or Quilt, which this launcher cannot install yet.');
       if(game!==target.game)throw new Error(`This pack is for Minecraft ${game}, but this instance uses ${target.game}. Create an instance for ${game} first.`);
       if(loader!=='vanilla'){
         const loaderVersion=String(deps[loaderKey]||'');if(!loaderVersion)throw new Error(`The Modrinth pack does not specify a ${loader} version.`);
         await require('./java').installLoader(loader,game,loaderVersion);
         installedVersion=loader==='fabric'?`fabric-loader-${loaderVersion}-${game}`:`${game}-forge-${loaderVersion}`;
       }
       for(const item of index.files||[]){
         if(item.env?.client==='unsupported')continue;
         const rel=String(item.path||'').replace(/\\/g,'/'),dest=safePackPath(stage,rel);let data=null;
         for(const url of item.downloads||[]){try{const r=await fetch(url);if(r.ok){data=Buffer.from(await r.arrayBuffer());break;}}catch{}}
         if(!data){if(item.env?.client==='optional'){result.skipped++;continue;}throw new Error(`Could not download ${path.posix.basename(rel)}.`);}
         if(data.length>500*1024*1024)throw new Error(`Pack file is too large: ${path.posix.basename(rel)}.`);
         if(item.fileSize&&data.length!==item.fileSize)throw new Error(`File size mismatch for ${path.posix.basename(rel)}.`);
         const hash=item.hashes?.sha1;if(hash&&crypto.createHash('sha1').update(data).digest('hex')!==hash)throw new Error(`Checksum mismatch for ${path.posix.basename(rel)}.`);
         fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,data);result.imported++;
       }
       unpack('overrides/');result.name=String(index.name||path.basename(source,path.extname(source)));
     }else{
       const manifest=JSON.parse(cfEntry.getData().toString('utf8')),game=String(manifest.minecraft?.version||''),loaderSpec=(manifest.minecraft?.modLoaders||[]).find(x=>x.primary)||manifest.minecraft?.modLoaders?.[0];
       if(!game)throw new Error('The CurseForge manifest does not specify a Minecraft version.');
       const spec=String(loaderSpec?.id||''),loader=loaderSpec?spec.split('-')[0]:'minecraft',loaderVersion=loaderSpec?spec.slice(loader.length+1):'';
       if(!['forge','fabric'].includes(loader)&&!(loader==='minecraft'&&!loaderVersion))throw new Error(`This pack uses unsupported loader ${loader||'(unknown)'}.`);
       if(game!==target.game)throw new Error(`This pack is for Minecraft ${game}, but this instance uses ${target.game}. Create an instance for ${game} first.`);
       if(!curseforgeKey)throw new Error('A CurseForge API key is required to import this pack. Add it in Launcher settings.');
       if(loader!=='minecraft'){
         if(!loaderVersion)throw new Error(`The CurseForge manifest does not specify a ${loader} version.`);
         await require('./java').installLoader(loader,game,loaderVersion);
         installedVersion=loader==='fabric'?`fabric-loader-${loaderVersion}-${game}`:`${game}-forge-${loaderVersion}`;
       }
       const manifestRoot=cfEntry.entryName.replace(/manifest\.json$/,'');
       for(const item of manifest.files||[]){
         if(!Number.isInteger(item.projectID)||!Number.isInteger(item.fileID))throw new Error('The CurseForge manifest contains an invalid mod reference.');
         const r=await fetch(`https://api.curseforge.com/v1/mods/${item.projectID}/files/${item.fileID}`,{headers:{'x-api-key':curseforgeKey,'User-Agent':'MambaLauncher/1.0'}});
         if(!r.ok){if(item.required===false){result.skipped++;continue;}throw new Error(`CurseForge could not resolve mod file ${item.fileID} (${r.status}).`);}
         const file=(await r.json()).data,url=file?.downloadUrl;
         if(!url){if(item.required===false){result.skipped++;continue;}throw new Error(`CurseForge did not provide a download for ${file?.fileName||item.fileID}.`);}
         const download=await fetch(url);if(!download.ok){if(item.required===false){result.skipped++;continue;}throw new Error(`Could not download ${file?.fileName||item.fileID} (${download.status}).`);}
         const bytes=Buffer.from(await download.arrayBuffer());if(bytes.length>300*1024*1024)throw new Error(`Mod file is too large: ${file.fileName||item.fileID}.`);
         const dest=safePackPath(stage,path.posix.join('mods',path.basename(file.fileName||`${item.fileID}.jar`)));
         fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,bytes);result.imported++;
       }
       unpack(`${manifestRoot}overrides/`);result.name=String(manifest.name||path.basename(source,path.extname(source)));
     }
     fs.cpSync(stage,gameDir(instance),{recursive:true,force:true});
     instance.version=installedVersion;
     fs.writeFileSync(path.join(instDir('java',id),'instance.json'),JSON.stringify(instance,null,2));
   }finally{try{fs.rmSync(stage,{recursive:true,force:true});}catch{}}
 }
 return result;
}
module.exports={search,versions,install,importIntoInstance};
