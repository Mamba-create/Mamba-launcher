const fs = require('fs'), path = require('path'), { execFileSync } = require('child_process'), { shell } = require('electron');
const { APPDATA, BE_ROOT, instDir, gameDir } = require('./store');
const LOCAL = process.env.LOCALAPPDATA || path.join(APPDATA, '..', 'Local');

// Where the game keeps its data. GDK build (new) first, then the old UWP build.
const CANDIDATES = [
  path.join(APPDATA, 'Minecraft Bedrock', 'Users', 'Shared', 'games', 'com.mojang'),
  path.join(LOCAL, 'Packages', 'Microsoft.MinecraftUWP_8wekyb3d8bbwe', 'LocalState', 'games', 'com.mojang')
];
const target = () => {
  const t = CANDIDATES.find(p => fs.existsSync(path.dirname(p)));
  if (!t) throw new Error('Minecraft Bedrock not found. Install it (Microsoft account) and run it once.');
  return t;
};
const running = () => { try { return execFileSync('tasklist', ['/FI', 'IMAGENAME eq Minecraft.Windows.exe', '/NH']).toString().includes('Minecraft.Windows.exe'); } catch { return false; } };
function stop(){
  let output='';
  try{output=execFileSync('tasklist',['/FI','IMAGENAME eq Minecraft.Windows.exe','/FO','CSV','/NH'],{encoding:'utf8'});}catch{throw new Error('Could not check whether Minecraft Bedrock is running.');}
  const pids=[...output.matchAll(/"Minecraft\.Windows\.exe","(\d+)"/gi)].map(match=>match[1]);
  if(!pids.length)return {stopped:false,message:'Minecraft Bedrock is not running.'};
  const stopped=[];
  for(const pid of pids){
    try{execFileSync('taskkill',['/PID',pid,'/T','/F'],{stdio:'ignore'});stopped.push(pid);}
    catch{throw new Error('Windows could not stop Minecraft Bedrock. Try closing it from Task Manager.');}
  }
  return {stopped:true,count:stopped.length};
}
const lstat = p => { try { return fs.lstatSync(p); } catch { return null; } };

// Isolation: point the game's com.mojang folder (junction) to the instance's own com.mojang folder.
function activate(inst) {
  const t = target(), dest = gameDir(inst); fs.mkdirSync(dest, { recursive: true });
  const s = lstat(t);
  if (running()) {
    if (s?.isSymbolicLink() && fs.realpathSync(t) === fs.realpathSync(dest)) return;   // already this instance
    throw new Error('Close Minecraft Bedrock first - the instance can only be switched while the game is closed');
  }
  if (s?.isSymbolicLink()) { try { fs.unlinkSync(t); } catch { fs.rmdirSync(t); } }
  else if (s) fs.renameSync(t, path.join(BE_ROOT, 'backup-original-com.mojang-' + Date.now()));  // never delete user data
  fs.symlinkSync(dest, t, 'junction');
}
async function launch(inst, server) {
  activate(inst);
  // The game uses its own Microsoft/Xbox account - the launcher stores nothing about it.
  await shell.openExternal(server ? `minecraft://connect/?serverUrl=${server.host}&serverPort=${server.port}` : 'minecraft://');
}
module.exports = { launch, stop };
