const fs = require('fs'), path = require('path'), crypto = require('crypto');
const AdmZip = require('adm-zip');
const { instDir, gameDir, getInstance } = require('./store');
const MR = 'https://api.modrinth.com/v2', CF = 'https://api.curseforge.com/v1';
const MCPA = 'https://mcpeaddons.com';
const cleanName=name=>path.basename(String(name||'').replace(/[<>:"/\\|?*]/g,'_'));
async function json(url, options) { const r = await fetch(url, options); if (!r.ok) throw new Error(`Catalog request failed (${r.status})`); return r.json(); }
async function html(url) { const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 (compatible; MambaLauncher/1.0)'}});if(!r.ok)throw new Error(`MCPE Addons request failed (${r.status})`);return r.text(); }
const unescapeHtml=s=>String(s||'').replace(/&amp;/g,'&').replace(/&#038;/g,'&').replace(/&quot;/g,'"').replace(/&#8217;|&rsquo;/g,"'").replace(/&#8211;|&ndash;/g,'–').replace(/&#8212;|&mdash;/g,'—').replace(/&#x([\da-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16))).replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n)));
const plain=s=>unescapeHtml(String(s||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim());
function profileInfo(inst) {
  const version = inst.version || '';
  if (version.startsWith('fabric-loader-') || version.includes('-forge-')) {
    const f = path.join(instDir(inst.edition, inst.id), '..', '..'); // resolved below from shared Java root
    const root = path.dirname(path.dirname(instDir(inst.edition, inst.id)));
    try {
      const meta = JSON.parse(fs.readFileSync(path.join(root,'versions',version,`${version}.json`),'utf8'));
      return { game: meta.inheritsFrom || version, loader: version.startsWith('fabric-loader-') ? 'fabric' : 'forge' };
    } catch { return { game: version, loader: 'vanilla' }; }
  }
  return { game: version, loader: 'vanilla' };
}
function context(ed,id) { const i=getInstance(ed,id); if(!i) throw new Error('Instance not found'); const v=profileInfo(i); return {i,...v}; }
const marker=(ed,id)=>path.join(instDir(ed,id),'mamba-content.json');
function installedMap(ed,id){let state={};try{state=JSON.parse(fs.readFileSync(marker(ed,id),'utf8'));}catch{return state;}let changed=false;const dirs={mods:'mods',resourcepacks:ed==='bedrock'?'resource_packs':'resourcepacks',shaderpacks:'shaderpacks',behaviorpacks:'behavior_packs'};for(const [key,val]of Object.entries(state)){const folder=dirs[val.kind];if(!folder||!val.name)continue;const file=path.join(gameDir(getInstance(ed,id)),folder,path.basename(val.name));if(!fs.existsSync(file)&&!fs.existsSync(file+'.disabled')){delete state[key];changed=true;}}if(changed)fs.writeFileSync(marker(ed,id),JSON.stringify(state,null,2));return state;}
async function search(ed,id,provider,query,apiKey='',kind='mod',offset=0) {
  if(ed==='bedrock')throw new Error('Bedrock packs are added from local .mcpack or .mcaddon files.');
  const {game,loader}=context(ed,id); query=String(query||'').trim();
  if(provider==='mcpeaddons') {
    if(ed!=='bedrock')throw new Error('MCPE Addons is only available for Bedrock.');
    const pageNum=Math.floor(offset/30)+1,slug=kind==='resourcepacks'?'texture-packs':'addons',expected=kind==='resourcepacks'?new Set(['texturepacks','resourcepacks']):new Set(['addon','addons']);let hits=[],total=0;
    try {
      const cats=await json(`${MCPA}/wp-json/wp/v2/categories?per_page=100`),ids=cats.filter(c=>expected.has(String(c.slug||'').toLowerCase().replace(/[^a-z]/g,''))||expected.has(String(c.name||'').toLowerCase().replace(/[^a-z]/g,''))).map(c=>c.id);
      if(!ids.length)throw new Error('Category not found');
      const loadCategory=async q=>{const u=new URL(`${MCPA}/wp-json/wp/v2/posts`);u.searchParams.set('categories',ids.join(','));if(q)u.searchParams.set('search',q);u.searchParams.set('per_page','30');u.searchParams.set('page',String(pageNum));u.searchParams.set('_embed','1');const res=await fetch(u);if(!res.ok)throw new Error(`MCPE Addons request failed (${res.status})`);return{items:await res.json(),total:Number(res.headers.get('X-WP-Total'))||0};};
      let found=await loadCategory(query);hits=found.items;total=found.total||hits.length;
      // Search each word as well: the site may not use the whole phrase in a
      // title (for example, "Xnova Remastered" is listed there as "Xnova Model V4").
      if(query&&query.trim().includes(' ')){const seen=new Set(hits.map(x=>x.link));for(const token of query.trim().split(/\s+/).filter(x=>x.length>2)){found=await loadCategory(token);for(const item of found.items){if(!seen.has(item.link)&&hits.length<30){seen.add(item.link);hits.push(item);}}total=Math.max(total,found.total||0);}}
      if(hits.length===30&&total<=offset+30)total=offset+31;
    } catch {
      // These archives are truly separate (Add-Ons vs Texture Packs); never
      // fall back to the site's global search, which mixes both content types.
      const archive=new URL(pageNum===1?`/${slug}/`:`/${slug}/page/${pageNum}/`,MCPA);if(query)archive.searchParams.set('s',query);
      const page=await html(archive),heading=/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi,seen=new Set();let m;
      while((m=heading.exec(page))&&hits.length<30){const inner=m[2],link=inner.match(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/i);if(!link)continue;let target;try{target=new URL(unescapeHtml(link[1]),MCPA);}catch{continue;}if(target.hostname!==new URL(MCPA).hostname)continue;const projectId=target.href.replace(/\/$/,''),title=plain(link[2]);if(!title||seen.has(projectId)||/\/(addons|texture-packs|category|tag)\/?$/i.test(target.pathname))continue;seen.add(projectId);const before=page.slice(Math.max(0,m.index-2400),m.index),card=before.slice(Math.max(before.lastIndexOf('<article'),before.lastIndexOf('<li'))),image=card.match(/<img\b[^>]*(?:src|data-src)=["']([^"']+)["']/i)?.[1];hits.push({url:projectId,title:{rendered:title},excerpt:{rendered:''},_embedded:{'wp:featuredmedia':image?[{source_url:new URL(unescapeHtml(image),MCPA).href}]:[]}});
      }
      total=offset+hits.length+(hits.length===30?1:0);
    }
    const results=hits.filter(x=>(x.url||x.link)&&x.title?.rendered).map(x=>{const title=plain(x.title.rendered),projectId=(x.url||x.link).replace(/\/$/,''),media=x._embedded?.['wp:featuredmedia']?.[0];return{id:projectId,title,description:plain(x.excerpt?.rendered||''),author:'MCPE Addons',downloads:0,icon:media?.source_url||'',source:'mcpeaddons',installed:!!installedMap(ed,id)[`mcpeaddons:resourcepacks:${projectId}`]};});
    const missing=results.filter(x=>!x.icon).slice(0,12);
    await Promise.all(missing.map(async item=>{try{const article=await html(item.id),meta=article.match(/<meta\b[^>]*(?:property|name)=["'](?:og:image|twitter:image)["'][^>]*content=["']([^"']+)["']/i)||article.match(/<meta\b[^>]*content=["']([^"']+)["'][^>]*(?:property|name)=["'](?:og:image|twitter:image)["']/i);if(meta?.[1])item.icon=new URL(unescapeHtml(meta[1]),MCPA).href;else{const image=article.match(/<img\b[^>]*(?:src|data-src)=["']([^"']+)["']/i)?.[1];if(image)item.icon=new URL(unescapeHtml(image),MCPA).href;}}catch{}}));
    return {game,loader,total,results};
  }
  if(provider==='modrinth') {
    const type=kind==='resourcepacks'?'resourcepack':kind==='shaderpacks'?'shader':'mod';
    const facets=[[`project_type:${type}`],[`versions:${game}`]]; if(type==='mod'&&loader!=='vanilla') facets.push([`categories:${loader}`]);
    const u=new URL(`${MR}/search`); if(query)u.searchParams.set('query',query); u.searchParams.set('facets',JSON.stringify(facets)); u.searchParams.set('limit','30');u.searchParams.set('offset',String(offset)); u.searchParams.set('index','downloads');
    const r=await json(u); const hits=loader==='vanilla'&&type==='mod'?r.hits.filter(x=>!(x.categories||[]).some(c=>['fabric','forge','neoforge','quilt'].includes(c))):r.hits;const done=installedMap(ed,id);
    return {game,loader,total:r.total_hits??r.total??0,results:hits.map(x=>({id:x.project_id,title:x.title,description:x.description,author:x.author,downloads:x.downloads,icon:x.icon_url,source:'modrinth',installed:!!done[`modrinth:${kind}:${x.project_id}`]}))};
  }
  if(provider==='curseforge') {
    if(!apiKey) throw new Error('Add your CurseForge API key in Launcher Settings to search CurseForge.');
    let classId='6';
    if(ed==='bedrock') {
      const cats=await json(`${CF}/categories?gameId=432`,{headers:{'x-api-key':apiKey,'Accept':'application/json'}});
      classId=(cats.data||[]).find(c=>c.isClass&&/add.?ons/i.test(c.name))?.id;
    }
    const u=new URL(`${CF}/mods/search`); for(const [k,v] of Object.entries({gameId:'432',...(classId?{classId:String(classId)}:{}),searchFilter:query,gameVersion:game,pageSize:'30',sortField:'6',sortOrder:'desc'})) u.searchParams.set(k,v);
    if(ed==='java' && loader!=='vanilla') u.searchParams.set('modLoaderType',loader==='fabric'?'4':'1');
    u.searchParams.set('index',String(offset));const r=await json(u,{headers:{'x-api-key':apiKey,'Accept':'application/json'}});
    return {game,loader,total:r.pagination?.totalCount||0,results:(r.data||[]).map(x=>({id:String(x.id),title:x.name,description:x.summary,author:x.authors?.[0]?.name,downloads:x.downloadCount,icon:x.logo?.url,source:'curseforge',installed:!!installedMap(ed,id)[`curseforge:${kind}:${x.id}`]}))};
  }
  throw new Error('Unknown mod source');
}
async function versions(ed,id,provider,projectId,apiKey='',kind='mods') {
  if(ed==='bedrock')throw new Error('Bedrock packs are added from local files.');
  const {game,loader}=context(ed,id);
  if(provider==='mcpeaddons') {
    if(ed!=='bedrock')throw new Error('MCPE Addons is only available for Bedrock.');
    const page=await html(projectId),links=[...page.matchAll(/<a\b[^>]*href=["'](https?:\/\/[^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)],files=[];
    for(const m of links){const url=unescapeHtml(m[1]),label=plain(m[2]),pathPart=new URL(url).pathname,ext=path.extname(pathPart).toLowerCase();if(!['.mcaddon','.mcpack','.zip'].includes(ext)||/linkvertise|direct-link\.net/i.test(url))continue;if(files.some(f=>f.url===url))continue;files.push({id:String(files.length),name:path.basename(pathPart)||`${plain(label)||'addon'}${ext}`,version:label||path.basename(pathPart),files:[{name:path.basename(pathPart)||`addon${ext}`,url}]});}
    return files;
  }
  if(provider==='modrinth') {
    const u=new URL(`${MR}/project/${encodeURIComponent(projectId)}/version`); u.searchParams.set('game_versions',JSON.stringify([game]));
    if(kind==='mods'&&loader!=='vanilla')u.searchParams.set('loaders',JSON.stringify([loader]));
    return (await json(u)).map(v=>({id:v.id,name:v.name,version:v.version_number,date:v.date_published,dependencies:v.dependencies||[],files:v.files.map(f=>({name:f.filename,url:f.url,primary:f.primary,size:f.size,hashes:f.hashes}))}));
  }
  if(provider==='curseforge') {
    if(kind!=='mods'&&ed==='java')throw new Error('CurseForge texture packs and shaders are coming soon.');
    const h={'x-api-key':apiKey,'Accept':'application/json'};
    const r=await json(`${CF}/mods/${encodeURIComponent(projectId)}/files?gameVersion=${encodeURIComponent(game)}&pageSize=50`,{headers:h});
    const list=(r.data||[]).filter(f=>ed==='bedrock'||loader==='vanilla'||f.modLoader=== (loader==='fabric'?4:1));
    return Promise.all(list.filter(f=>ed!=='bedrock'||/\.(mcaddon|mcpack|zip)$/i.test(f.fileName||'')).map(async f=>{let url=f.downloadUrl;if(!url){try{url=(await json(`${CF}/mods/${projectId}/files/${f.id}/download-url`,{headers:h})).data;}catch{}}return {id:String(f.id),name:f.displayName,version:f.fileName,date:f.fileDate,files:[{name:f.fileName,url}]};}));
  }
  throw new Error('Unknown mod source');
}
async function install(ed,id,provider,projectId,fileUrl,fileName,kind='mods',versionId='',apiKey='',metadata={}) {
  if(ed==='bedrock')throw new Error('Bedrock packs are added from local files.');
  const {i,game,loader}=context(ed,id); if(!/^https:\/\//i.test(fileUrl))throw new Error('Invalid download URL');
  const ext=path.extname(String(fileName||new URL(fileUrl).pathname).split('?')[0]).toLowerCase();
  const bedrock=ed==='bedrock';
  if(bedrock&&!['.mcaddon','.mcpack','.zip'].includes(ext))throw new Error('This file is not a supported Bedrock add-on.');
  if(!bedrock&&!['.jar','.zip'].includes(ext))throw new Error('This file is not a supported Java mod or pack.');
  const targets={mods:'mods',resourcepacks:'resourcepacks',shaderpacks:'shaderpacks'};if(bedrock)kind='resourcepacks';
  const rel=targets[kind];if(!rel)throw new Error('Unsupported content type');
  const installedState=installedMap(ed,id),key=`${provider}:${kind}:${projectId}`,dependencyProjects=[];if(installedState[key])throw new Error('This project is already installed in this instance.');
  const dir=bedrock?path.join(gameDir(i),'resource_packs'):path.join(gameDir(i),rel);fs.mkdirSync(dir,{recursive:true});
  const visited=new Set(),curseforgeDependencies=[],curseforgeFiles=[];let installed=0,total=0;
  async function put(url,name,hashes={}){if(++total>32)throw new Error('This project has too many required dependencies.');const safe=cleanName(name||new URL(url).pathname);if(!safe)throw new Error('Invalid download filename');const dest=path.join(dir,safe);if(fs.existsSync(dest))return;const res=await fetch(url);if(!res.ok)throw new Error(`Download failed (${res.status})`);const data=Buffer.from(await res.arrayBuffer());if(data.length>300*1024*1024)throw new Error('A file exceeds 300 MB limit.');if(hashes.sha1&&crypto.createHash('sha1').update(data).digest('hex')!==hashes.sha1)throw new Error(`Checksum mismatch: ${safe}`);fs.writeFileSync(dest+'.part',data);fs.renameSync(dest+'.part',dest);installed++;}
  if(provider==='curseforge'&&kind==='mods'&&versionId){
    if(!apiKey)throw new Error('Add your CurseForge API key in Launcher Settings to install required dependencies.');
    const headers={'x-api-key':apiKey,'Accept':'application/json'};
    async function getFile(modId,fileId){
      const file=await json(`${CF}/mods/${encodeURIComponent(modId)}/files/${encodeURIComponent(fileId)}`,{headers}).then(r=>r.data);
      if(!file)throw new Error(`CurseForge file ${fileId} was not found.`);
      if(!file.downloadUrl){try{file.downloadUrl=(await json(`${CF}/mods/${modId}/files/${fileId}/download-url`,{headers})).data;}catch{}}
      if(!file.downloadUrl)throw new Error(`No download URL for required mod ${modId} (${file.fileName||fileId}).`);
      return file;
    }
    async function resolve(modId,fileId,isRoot=false){
      const file=await getFile(modId,fileId),identity=`${modId}:${file.id}`;if(visited.has(identity))return;visited.add(identity);
      for(const dep of file.dependencies||[]){
        if(![1,3].includes(Number(dep.relationType)))continue;
        let required=dep.fileId;
        if(!required){
          const q=new URL(`${CF}/mods/${dep.modId}/files`);q.searchParams.set('gameVersion',game);q.searchParams.set('pageSize','50');
          const response=await json(q,{headers}),choices=(response.data||[]).filter(candidate=>candidate.gameVersions?.includes(game)&&(loader==='vanilla'||candidate.modLoader===(loader==='fabric'?4:1)));
          required=choices[0]?.id;if(!required)throw new Error(`No compatible required file found for CurseForge mod ${dep.modId} (${game}, ${loader}).`);
        }
        await resolve(dep.modId,required);
      }
      const hash=(file.hashes||[]).find(x=>x.algo===1||String(x.algo).toLowerCase()==='sha1')?.value;
      if(!isRoot)curseforgeDependencies.push({id:String(modId),name:file.fileName});
      curseforgeFiles.push({url:file.downloadUrl,name:file.fileName,hash:hash?{sha1:hash}:{}});
    }
    await resolve(projectId,versionId,true);
    for(const file of curseforgeFiles)await put(file.url,file.name,file.hash);
  } else if(provider==='modrinth'&&kind==='mods'&&!bedrock&&versionId){
    async function dependency(vid){if(visited.has(vid))return;visited.add(vid);const v=await json(`${MR}/version/${encodeURIComponent(vid)}`);if(v.project_id&&installedState[`modrinth:mods:${v.project_id}`])return;for(const dep of v.dependencies||[]){if(dep.dependency_type!=='required')continue;let depId=dep.version_id;if(!depId&&dep.project_id){const projectUrl=`${MR}/project/${encodeURIComponent(dep.project_id)}/version`,u=new URL(projectUrl);u.searchParams.set('game_versions',JSON.stringify([game]));if(loader!=='vanilla')u.searchParams.set('loaders',JSON.stringify([loader]));let compatible=await json(u);if(!compatible.length){const all=await json(projectUrl),parts=String(game).split('.'),loaderMatches=x=>loader==='vanilla'||!x.loaders?.length||x.loaders.includes(loader),sameLine=x=>(x.game_versions||[]).some(g=>{const p=String(g).split('.');return p.length>=2&&parts.length>=2&&p[0]===parts[0]&&p[1]===parts[1];});compatible=all.filter(x=>loaderMatches(x)&&((x.game_versions||[]).includes(game)||sameLine(x)||!x.game_versions?.length));}depId=compatible[0]?.id;if(!depId)throw new Error(`Required dependency ${dep.project_id} has no compatible version for Minecraft ${game} (${loader}).`);}if(depId)await dependency(depId);}const f=v.files?.find(x=>x.primary)||v.files?.[0];if(!f?.url)throw new Error(`Missing file for required mod ${v.project_id||vid}`);await put(f.url,f.filename,f.hashes||{});if(v.project_id)dependencyProjects.push({id:v.project_id,name:f.filename});}
    await dependency(versionId);
  } else await put(fileUrl,fileName);
  const record={provider,kind,projectId,name:cleanName(fileName||new URL(fileUrl).pathname),title:String(metadata.title||'').slice(0,120),icon:/^https:\/\//.test(metadata.icon||'')?metadata.icon:'',installedAt:Date.now()};installedState[key]=record;for(const dep of dependencyProjects)installedState[`modrinth:mods:${dep.id}`]={provider:'modrinth',kind:'mods',projectId:dep.id,name:cleanName(dep.name),title:'Required dependency',icon:'',installedAt:record.installedAt};for(const dep of curseforgeDependencies)installedState[`curseforge:mods:${dep.id}`]={provider:'curseforge',kind:'mods',projectId:dep.id,name:cleanName(dep.name),title:'Required dependency',icon:'',installedAt:record.installedAt};fs.writeFileSync(marker(ed,id),JSON.stringify(installedState,null,2));
  return {name:record.name,size:installed,installed};
}
function importBedrock(id,filePaths){
  const {i}=context('bedrock',id),result={imported:[],errors:[]},root=gameDir(i);
  const target={resource:'resource_packs',behavior:'behavior_packs'};
  const cleanFolder=s=>String(s||'Pack').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/[. ]+$/,'').trim().slice(0,80)||'Pack';
  const uniquePath=(dir,name)=>{let candidate=path.join(dir,name),n=2;while(fs.existsSync(candidate))candidate=path.join(dir,`${name} (${n++})`);return candidate;};
  for(const source of filePaths){
    const stages=[];
    try{
      if(!['.mcpack','.mcaddon','.zip'].includes(path.extname(source).toLowerCase()))throw new Error('Choose .mcpack, .mcaddon, or .zip files.');
      const stat=fs.statSync(source);if(!stat.isFile()||stat.size>300*1024*1024)throw new Error('Each pack file must be smaller than 300 MB.');
      const zip=new AdmZip(source),entries=zip.getEntries().filter(e=>!e.isDirectory),byPath=new Map();
      if(entries.length>5000)throw new Error('The archive contains too many files.');
      let totalSize=0;
      for(const entry of entries){
        const name=entry.entryName.replace(/\\/g,'/');
        if(name.startsWith('/')||/^[a-z]:/i.test(name)||name.split('/').some(part=>part==='..'))throw new Error('The archive contains an unsafe file path.');
        totalSize+=entry.header.size;if(entry.header.size>300*1024*1024||totalSize>500*1024*1024)throw new Error('The uncompressed pack contents exceed 500 MB.');
        byPath.set(name,entry);
      }
      const manifests=[];
      for(const [name,entry] of byPath){
        if(path.posix.basename(name).toLowerCase()!=='manifest.json'||entry.header.size>1024*1024)continue;
        let manifest;try{manifest=JSON.parse(entry.getData().toString('utf8'));}catch{continue;}
        const modules=Array.isArray(manifest.modules)?manifest.modules.filter(Boolean):[];
        const types=modules.map(m=>String(m.type||'').toLowerCase());
        const kind=types.some(t=>['data','script','world_template'].includes(t))?'behavior':types.includes('resources')?'resource':null;
        if(kind)manifests.push({root:name.slice(0,name.lastIndexOf('/')+1),kind,label:manifest.header?.name});
      }
      if(!manifests.length)throw new Error('No valid Bedrock pack manifest was found.');
      const roots=[...new Set(manifests.map(p=>p.root))];
      for(const pack of manifests){
        const parent=path.join(root,target[pack.kind]);fs.mkdirSync(parent,{recursive:true});
        const stage=path.join(parent,`.mamba-import-${crypto.randomBytes(6).toString('hex')}`);fs.mkdirSync(stage);stages.push(stage);
        const prefix=pack.root;
        for(const [name,entry] of byPath){
          if(prefix&&!name.startsWith(prefix))continue;
          const relative=prefix?name.slice(prefix.length):name;
          if(!relative||roots.some(other=>other!==prefix&&other.startsWith(prefix)&&relative.startsWith(other.slice(prefix.length))))continue;
          const parts=relative.split('/');if(parts.some(part=>!part||part==='.'||part==='..'))continue;
          const out=path.join(stage,...parts);fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,entry.getData());
        }
        const destination=uniquePath(parent,cleanFolder(pack.label||path.basename(source,path.extname(source))));
        fs.renameSync(stage,destination);stages.splice(stages.indexOf(stage),1);
        result.imported.push({name:path.basename(destination),kind:pack.kind==='resource'?'resourcepacks':'behaviorpacks'});
      }
    }catch(error){result.errors.push({file:path.basename(source),message:error.message||'Could not import this pack.'});}
    finally{for(const stage of stages)try{fs.rmSync(stage,{recursive:true,force:true});}catch{}}
  }
  return result;
}
function manage(ed,id,action,kind,name){const {i}=context(ed,id),dirs={mods:'mods',resourcepacks:ed==='bedrock'?'resource_packs':'resourcepacks',shaderpacks:'shaderpacks',behaviorpacks:'behavior_packs'};const dir=dirs[kind];if(!dir)throw new Error('Unsupported content folder');const root=path.resolve(gameDir(i),dir);const file=path.resolve(root,String(name||''));if(!file.startsWith(root+path.sep)||!fs.existsSync(file))throw new Error('Content not found');if(action==='delete'){const basename=path.basename(file).replace(/\.disabled$/,'');fs.rmSync(file,{recursive:fs.statSync(file).isDirectory(),force:true});const state=installedMap(ed,id),removed=[];for(const [key,val] of Object.entries(state))if(val.kind===kind&&val.name===basename){removed.push(val);delete state[key];}fs.writeFileSync(marker(ed,id),JSON.stringify(state,null,2));return {deleted:true,removed};}if(action==='toggle'){const disabled=file.endsWith('.disabled'),dest=disabled?file.slice(0,-9):file+'.disabled';if(fs.existsSync(dest))throw new Error('A pack with that name already exists');fs.renameSync(file,dest);return {name:path.basename(dest),disabled:!disabled};}throw new Error('Unknown action');}
module.exports={search,versions,install,manage,importBedrock};
