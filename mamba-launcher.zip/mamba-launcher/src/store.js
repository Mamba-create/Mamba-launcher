const fs = require('fs'), path = require('path'), crypto = require('crypto'), os = require('os');
const APPDATA = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
const JAVA_ROOT = path.join(APPDATA, '.minecraft_java');
const BE_ROOT = path.join(APPDATA, '.minecraft_bedrock');          // %appdata%\.minecraft_bedrock
const CFG_FILE = path.join(APPDATA, '.minecraft_launcher', 'launcher.json');
const ROOTS = { java: JAVA_ROOT, bedrock: BE_ROOT };
const INST = 'instances';                                          // %appdata%\.minecraft_bedrock\instances

// Every instance = its own folder. Java: <id>/minecraft, Bedrock: <id>/com.mojang
const instDir = (ed, id) => {
  if (!ROOTS[ed] || !/^[\w.\-]+$/.test(id)) throw new Error('Bad instance');
  return path.join(ROOTS[ed], INST, id);
};
const gameDir = i => path.join(instDir(i.edition, i.id), i.edition === 'java' ? 'minecraft' : 'com.mojang');
const rj = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const wj = (f, o) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(o, null, 2)); };
const count = p => { try { return fs.readdirSync(p).length; } catch { return 0; } };
const DEF = { settings: { javaPath: '', ramMin: 512, ramMax: 4096, jvmArgs: '', jvmPreset: 'none', msClientId: '' }, accounts: [], activeAccount: null, servers: [] };
const cfg = () => { const c = rj(CFG_FILE, {}); return { ...DEF, ...c, settings: { ...DEF.settings, ...c.settings } }; };
const save = c => wj(CFG_FILE, c);
const uid = () => crypto.randomBytes(4).toString('hex');

function getInstance(ed, id) { return rj(path.join(instDir(ed, id), 'instance.json'), null); }
function listInstances(ed) {
  if (!ROOTS[ed]) throw new Error('Bad edition');
  const base = path.join(ROOTS[ed], INST); fs.mkdirSync(base, { recursive: true });
  return fs.readdirSync(base).map(id => getInstance(ed, id)).filter(Boolean).map(i => {
    const g = gameDir(i);
    const stats = ed === 'java'
      ? { mods: count(path.join(g, 'mods')), worlds: count(path.join(g, 'saves')) }
      : { worlds: count(path.join(g, 'minecraftWorlds')), packs: count(path.join(g, 'behavior_packs')) + count(path.join(g, 'resource_packs')) };
    return { ...i, stats };
  }).sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0) || a.created - b.created);
}
function createInstance({ edition, name, version }) {
  name = String(name || '').trim().slice(0, 40); if (!name) throw new Error('Name is required');
  const id = (name.toLowerCase().replace(/[^\w]+/g, '-').replace(/^-|-$/g, '') || 'instance') + '-' + uid();
  const inst = { id, edition, name, version: String(version || (edition === 'java' ? '' : 'Installed')).slice(0, 40), created: Date.now(), lastPlayed: 0 };
  fs.mkdirSync(gameDir(inst), { recursive: true });
  wj(path.join(instDir(edition, id), 'instance.json'), inst);
  return inst;
}
const deleteInstance = (ed, id) => fs.rmSync(instDir(ed, id), { recursive: true, force: true });
const touch = i => wj(path.join(instDir(i.edition, i.id), 'instance.json'), { ...i, lastPlayed: Date.now() });

// ---- Java offline accounts (Bedrock uses the game's own account, nothing is stored here)
function offlineUUID(name) {
  const b = crypto.createHash('md5').update('OfflinePlayer:' + name).digest();
  b[6] = (b[6] & 0x0f) | 0x30; b[8] = (b[8] & 0x3f) | 0x80;
  const h = b.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
const accountsInfo = () => { const c = cfg(); return { accounts: c.accounts.map(({ refresh, ...a }) => a), active: c.activeAccount }; };  // tokens never go to the UI
function addAccount(name) {
  name = String(name || '').trim();
  if (!/^\w{3,16}$/.test(name)) throw new Error('Nickname: 3-16 chars, letters/digits/_');
  const c = cfg();
  if (c.accounts.some(a => a.name.toLowerCase() === name.toLowerCase())) throw new Error('Account already exists');
  const a = { id: uid(), name, uuid: offlineUUID(name), type: 'offline' };
  c.accounts.push(a); c.activeAccount ||= a.id; save(c); return accountsInfo();
}
function addMicrosoft(p) {
  const c = cfg(); let a = c.accounts.find(x => x.type === 'microsoft' && x.uuid === p.uuid);
  if (a) Object.assign(a, p); else { a = { id: uid(), type: 'microsoft', ...p }; c.accounts.push(a); }
  c.activeAccount = a.id; save(c); return accountsInfo();
}
function setRefresh(id, r) { const c = cfg(), a = c.accounts.find(x => x.id === id); if (a) { a.refresh = r; save(c); } }
function removeAccount(id) { const c = cfg(); c.accounts = c.accounts.filter(a => a.id !== id); if (c.activeAccount === id) c.activeAccount = c.accounts[0]?.id || null; save(c); return accountsInfo(); }
function selectAccount(id) { const c = cfg(); if (c.accounts.some(a => a.id === id)) { c.activeAccount = id; save(c); } return accountsInfo(); }

function saveSettings(s) {
  const c = cfg(), n = v => Math.max(256, Math.min(65536, parseInt(v) || 0));
  c.settings = { javaPath: String(s.javaPath || '').trim(), ramMin: n(s.ramMin), ramMax: n(s.ramMax), jvmArgs: String(s.jvmArgs || '').trim(), jvmPreset: String(s.jvmPreset || 'none'), msClientId: /^[0-9a-f-]{36}$/i.test(s.msClientId || '') ? s.msClientId.trim() : '' };
  if (c.settings.ramMin > c.settings.ramMax) c.settings.ramMin = c.settings.ramMax;
  save(c); return c.settings;
}
function addServer(s) {
  const host = String(s.host || '').trim(), port = parseInt(s.port) || (s.edition === 'java' ? 25565 : 19132);
  if (!/^[\w.\-]{1,253}$/.test(host) || port < 1 || port > 65535) throw new Error('Bad server address');
  if (!ROOTS[s.edition]) throw new Error('Bad edition');
  const c = cfg(); c.servers.push({ id: uid(), name: String(s.name || host).slice(0, 40), host, port, edition: s.edition, instanceId: s.instanceId });
  save(c); return c.servers;
}
function removeServer(id) { const c = cfg(); c.servers = c.servers.filter(s => s.id !== id); save(c); return c.servers; }
const paths = () => ({ java: path.join(JAVA_ROOT, INST), bedrock: path.join(BE_ROOT, INST), config: CFG_FILE });

module.exports = { APPDATA, JAVA_ROOT, BE_ROOT, instDir, gameDir, cfg, getInstance, listInstances, createInstance, deleteInstance, touch,
  accountsInfo, addAccount, addMicrosoft, setRefresh, removeAccount, selectAccount, saveSettings, addServer, removeServer, paths };
