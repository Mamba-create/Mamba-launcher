// Microsoft (online) login for Java: device-code flow -> Xbox Live -> XSTS -> Minecraft services.
const { safeStorage, shell } = require('electron');
const TENANT = 'https://login.microsoftonline.com/consumers/oauth2/v2.0', SCOPE = 'XboxLive.signin offline_access';
const J = async (url, opt) => { const r = await fetch(url, opt); let d = {}; try { d = await r.json(); } catch {} return { ok: r.ok, status: r.status, d }; };
const form = o => ({ method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(o).toString() });
const jpost = o => ({ method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(o) });
const dash = h => `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
const enc = s => { if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is unavailable'); return safeStorage.encryptString(s).toString('base64'); };
const dec = s => safeStorage.decryptString(Buffer.from(s, 'base64'));
let cancelled = false; const cache = new Map();
const cancel = () => { cancelled = true; };

async function deviceLogin(clientId, send) {
  if (!/^[0-9a-f-]{36}$/i.test(clientId || '')) throw new Error('Set your Azure Client ID in Settings first');
  cancelled = false;
  const dc = await J(TENANT + '/devicecode', form({ client_id: clientId, scope: SCOPE }));
  if (!dc.ok) throw new Error(dc.d.error_description || 'Device code request failed');
  send('msdevice', { code: dc.d.user_code, uri: dc.d.verification_uri });
  shell.openExternal(dc.d.verification_uri);
  let wait = (dc.d.interval || 5) * 1000; const end = Date.now() + dc.d.expires_in * 1000;
  while (Date.now() < end) {
    await new Promise(r => setTimeout(r, wait)); if (cancelled) throw new Error('Login cancelled');
    const t = await J(TENANT + '/token', form({ grant_type: 'urn:ietf:params:oauth:grant-type:device_code', client_id: clientId, device_code: dc.d.device_code }));
    if (t.ok) return t.d;
    if (t.d.error === 'authorization_pending') continue;
    if (t.d.error === 'slow_down') { wait += 5000; continue; }
    throw new Error(t.d.error_description || t.d.error);
  }
  throw new Error('Login code expired');
}
async function refreshMs(clientId, rt) {
  const t = await J(TENANT + '/token', form({ grant_type: 'refresh_token', client_id: clientId, refresh_token: rt, scope: SCOPE }));
  if (!t.ok) throw new Error('Microsoft session expired - sign in again'); return t.d;
}
async function minecraftFrom(ms) {
  const xbl = await J('https://user.auth.xboxlive.com/user/authenticate', jpost({ Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: 'd=' + ms.access_token }, RelyingParty: 'http://auth.xboxlive.com', TokenType: 'JWT' }));
  if (!xbl.ok) throw new Error('Xbox Live auth failed (' + xbl.status + ')');
  const xsts = await J('https://xsts.auth.xboxlive.com/xsts/authorize', jpost({ Properties: { SandboxId: 'RETAIL', UserTokens: [xbl.d.Token] }, RelyingParty: 'rp://api.minecraftservices.com/', TokenType: 'JWT' }));
  if (!xsts.ok) { const E = { 2148916233: 'This Microsoft account has no Xbox profile - create one at xbox.com', 2148916238: 'Child account: it must be added to a Microsoft Family' }; throw new Error(E[xsts.d.XErr] || 'XSTS failed (' + (xsts.d.XErr || xsts.status) + ')'); }
  const mc = await J('https://api.minecraftservices.com/authentication/login_with_xbox', jpost({ identityToken: `XBL3.0 x=${xsts.d.DisplayClaims.xui[0].uhs};${xsts.d.Token}` }));
  if (!mc.ok) throw new Error(mc.status === 403 ? 'Minecraft API refused this app (403). Your Azure app must be approved by Mojang: https://aka.ms/AppRegInfo' : 'Minecraft login failed (' + mc.status + ')');
  return mc.d;
}
async function mcProfile(token) {
  const p = await J('https://api.minecraftservices.com/minecraft/profile', { headers: { Authorization: 'Bearer ' + token } });
  if (p.status === 404) throw new Error('This account does not own Minecraft: Java Edition');
  if (!p.ok) throw new Error('Cannot read Minecraft profile'); return p.d;
}
async function login(clientId, send) {
  const ms = await deviceLogin(clientId, send), mc = await minecraftFrom(ms), p = await mcProfile(mc.access_token);
  return { name: p.name, uuid: dash(p.id), refresh: enc(ms.refresh_token) };
}
async function session(acc, clientId, saveRefresh) {
  const c = cache.get(acc.id); if (c && c.exp > Date.now() + 60000) return c.s;
  const ms = await refreshMs(clientId, dec(acc.refresh)), mc = await minecraftFrom(ms);
  if (ms.refresh_token) saveRefresh(enc(ms.refresh_token));
  const s = { name: acc.name, uuid: acc.uuid, token: mc.access_token, userType: 'msa' };
  cache.set(acc.id, { s, exp: Date.now() + mc.expires_in * 1000 }); return s;
}
module.exports = { login, session, cancel };
