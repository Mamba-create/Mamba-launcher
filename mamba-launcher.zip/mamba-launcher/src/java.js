const fs = require('fs'), path = require('path'), crypto = require('crypto'), { spawn } = require('child_process');
const AdmZip = require('adm-zip');
const { JAVA_ROOT, instDir, gameDir } = require('./store');
const R = (...p) => path.join(JAVA_ROOT, ...p);          // shared: libraries / assets / versions
const MANIFEST = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const RT_ALL = 'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';
const sha1 = b => crypto.createHash('sha1').update(b).digest('hex');
const getJson = async u => { const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}: ${u}`); return r.json(); };

async function fetchFile(u, dest, hash) {
  if (fs.existsSync(dest) && (!hash || sha1(fs.readFileSync(dest)) === hash)) return;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}: ${u}`);
  const b = Buffer.from(await r.arrayBuffer());
  if (hash && sha1(b) !== hash) throw new Error('Checksum mismatch: ' + u);
  fs.writeFileSync(dest + '.part', b); fs.renameSync(dest + '.part', dest);
}
async function pool(items, n, fn) { let i = 0; await Promise.all(Array.from({ length: n }, async () => { while (i < items.length) await fn(items[i++]); })); }

// Mojang rule evaluation (Windows, no optional features)
function allowed(rules) {
  if (!rules) return true; let ok = false;
  for (const r of rules) if ((!r.os || (r.os.name === 'windows' && r.os.arch !== 'x86')) && !r.features) ok = r.action === 'allow';
  return ok;
}
let mf; const manifest = async () => (mf ??= await getJson(MANIFEST));
const isInstalled = id => fs.existsSync(R('versions', id, id + '.ready'));
const installedList = () => { try { return fs.readdirSync(R('versions')).filter(isInstalled); } catch { return []; } };
async function list() {
  const m = await manifest();
  return { latest: m.latest, versions: m.versions.map(v => ({ id: v.id, type: v.type, date: v.releaseTime })), installed: installedList() };
}
async function meta(id) {
  if (!/^[\w.\-]+$/.test(id)) throw new Error('Bad version id');
  const f = R('versions', id, id + '.json');
  if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, 'utf8'));
  const v = (await manifest()).versions.find(x => x.id === id); if (!v) throw new Error('Unknown version ' + id);
  const m = await getJson(v.url); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(m)); return m;
}

async function install(id, send = () => {}) {
  if (isInstalled(id)) return;
  const m = await meta(id), jobs = [], natives = [];
  jobs.push({ u: m.downloads.client.url, d: R('versions', id, id + '.jar'), h: m.downloads.client.sha1 });
  for (const l of m.libraries) {
    if (!allowed(l.rules)) continue;
    const a = l.downloads?.artifact; if (a?.url) jobs.push({ u: a.url, d: R('libraries', a.path), h: a.sha1 });
    const key = l.natives?.windows?.replace('${arch}', '64'), c = key && l.downloads?.classifiers?.[key];   // legacy (<1.19) natives
    if (c) { jobs.push({ u: c.url, d: R('libraries', c.path), h: c.sha1 }); natives.push(R('libraries', c.path)); }
  }
  const idx = await getJson(m.assetIndex.url);
  fs.mkdirSync(R('assets', 'indexes'), { recursive: true });
  fs.writeFileSync(R('assets', 'indexes', m.assetIndex.id + '.json'), JSON.stringify(idx));
  for (const h of new Set(Object.values(idx.objects).map(o => o.hash)))
    jobs.push({ u: `https://resources.download.minecraft.net/${h.slice(0, 2)}/${h}`, d: R('assets', 'objects', h.slice(0, 2), h) });
  let done = 0;
  await pool(jobs, 16, async j => { await fetchFile(j.u, j.d, j.h); if (++done % 20 === 0 || done === jobs.length) send('progress', { text: `Installing ${id}: ${done}/${jobs.length}`, p: done / jobs.length }); });
  const nd = R('versions', id, 'natives'); fs.mkdirSync(nd, { recursive: true });
  for (const n of natives) new AdmZip(n).getEntries().forEach(e => { if (!e.isDirectory && !e.entryName.startsWith('META-INF')) fs.writeFileSync(path.join(nd, path.basename(e.entryName)), e.getData()); });
  fs.writeFileSync(R('versions', id, id + '.ready'), '1');
  send('progress', { text: `Installed ${id}`, p: 0 });
}

// Java: custom path from Settings, otherwise download the exact runtime this Minecraft version needs.
async function javaFor(m, custom, send) {
  custom = (custom || '').trim();
  if (custom && !['java', 'auto'].includes(custom.toLowerCase())) return custom;
  const comp = m.javaVersion?.component || 'jre-legacy', dir = R('runtime', comp), exe = path.join(dir, 'bin', 'java.exe');
  if (fs.existsSync(path.join(dir, '.ready'))) return exe;
  const plat = { x64: 'windows-x64', arm64: 'windows-arm64', ia32: 'windows-x86' }[process.arch];
  const e = (await getJson(RT_ALL))[plat]?.[comp]?.[0];
  if (!e) throw new Error(`No automatic Java (${comp}) for ${plat}. Install Java and set its path in Settings`);
  const files = Object.entries((await getJson(e.manifest.url)).files).filter(([, f]) => f.type === 'file');
  let done = 0;
  await pool(files, 12, async ([p, f]) => {
    const dest = path.join(dir, p); if (!dest.startsWith(dir + path.sep)) return;
    await fetchFile(f.downloads.raw.url, dest, f.downloads.raw.sha1);
    if (++done % 10 === 0 || done === files.length) send('progress', { text: `Downloading Java (${comp}): ${done}/${files.length}`, p: done / files.length });
  });
  fs.writeFileSync(path.join(dir, '.ready'), '1'); return exe;
}

async function launch(inst, acc, cfg, server, send) {
  const id = inst.version; if (!id) throw new Error('Instance has no version');
  await install(id, send);
  const m = await meta(id), gd = gameDir(inst); fs.mkdirSync(gd, { recursive: true });
  const javaExe = await javaFor(m, cfg.javaPath, send);
  const cp = [...m.libraries.filter(l => allowed(l.rules) && l.downloads?.artifact).map(l => R('libraries', l.downloads.artifact.path)), R('versions', id, id + '.jar')].join(';');
  const V = { auth_player_name: acc.name, auth_uuid: acc.uuid.replace(/-/g, ''), auth_access_token: acc.token || '0', clientid: '0', auth_xuid: '0', user_type: acc.userType || 'legacy', user_properties: '{}', auth_session: '0',
    version_name: id, version_type: m.type, game_directory: gd, assets_root: R('assets'), assets_index_name: m.assetIndex.id, game_assets: R('assets', 'virtual', 'legacy'),
    natives_directory: R('versions', id, 'natives'), launcher_name: 'MambaLauncher', launcher_version: '1.0', classpath: cp, library_directory: R('libraries'), classpath_separator: ';' };
  const sub = s => s.replace(/\$\{(\w+)\}/g, (_, k) => V[k] ?? '');
  const walk = arr => (arr || []).flatMap(a => typeof a === 'string' ? [a] : allowed(a.rules) ? [].concat(a.value) : []);
  let jvm, game;
  if (m.arguments) { jvm = walk(m.arguments.jvm); game = walk(m.arguments.game); }
  else { jvm = ['-Djava.library.path=${natives_directory}', '-cp', '${classpath}']; game = m.minecraftArguments.split(' '); }
  if (server) game.push('--server', server.host, '--port', String(server.port));
  const user = cfg.jvmArgs.split(/\s+/).filter(a => a.startsWith('-'));   // the unlock flag must come first, otherwise experimental flags (G1NewSizePercent...) kill the JVM
  const args = [`-Xms${cfg.ramMin}M`, `-Xmx${cfg.ramMax}M`, ...(user.length ? ['-XX:+UnlockExperimentalVMOptions'] : []), ...user, ...jvm.map(sub), m.mainClass, ...game.map(sub)];
  send('progress', { text: `Launching ${inst.name}...`, p: 0 });
  const c = spawn(javaExe, args, { cwd: gd, windowsHide: true });
  await new Promise((res, rej) => { c.once('spawn', res); c.once('error', e => rej(new Error('Cannot start Java: ' + e.message + ' (set the Java path in Settings)'))); });
  const log = d => send('log', d.toString()); c.stdout.on('data', log); c.stderr.on('data', log);
  c.on('close', code => send('exit', { id: inst.id, code }));
}
module.exports = { list, install, launch };
