const fs = require('fs'), path = require('path'), crypto = require('crypto'), { spawn } = require('child_process');
const AdmZip = require('adm-zip');
const { JAVA_ROOT, instDir, gameDir } = require('./store');
const { execFileSync } = require('child_process');
const activeGames = new Map();
const R = (...p) => path.join(JAVA_ROOT, ...p);          // shared: libraries / assets / versions
const MANIFEST = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const RT_ALL = 'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';
const sha1 = b => crypto.createHash('sha1').update(b).digest('hex');
const getJson = async u => { const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}: ${u}`); return r.json(); };

async function fetchFile(u, dest, hash) {
  if (fs.existsSync(dest) && (!hash || sha1(fs.readFileSync(dest)) === hash)) return;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}: ${u}`);
  const b = Buffer.from(await r.arrayBuffer());
  if (hash && sha1(b) !== hash) throw new Error('Checksum mismatch: ' + u);
  fs.writeFileSync(dest + '.part', b); fs.renameSync(dest + '.part', dest);
}
async function pool(items, n, fn) { let i = 0; await Promise.all(Array.from({ length: n }, async () => { while (i < items.length) await fn(items[i++]); })); }

// Mojang rule evaluation (Windows, no optional features)
function allowed(rules) {
  if (!rules) return true; let ok = false;
  for (const r of rules) if ((!r.os || (r.os.name === 'windows' && r.os.arch !== 'x86')) && !r.features) ok = r.action === 'allow';
  return ok;
}
let mf; const manifest = async () => (mf ??= await getJson(MANIFEST));
const isInstalled = id => fs.existsSync(R('versions', id, id + '.ready'));
const installedList = () => { try { return fs.readdirSync(R('versions')).filter(isInstalled); } catch { return []; } };
async function list() {
  const m = await manifest();
  return { latest: m.latest, versions: m.versions.map(v => ({ id: v.id, type: v.type, date: v.releaseTime })), installed: installedList() };
}
async function meta(id) {
  if (!/^[\w.\-]+$/.test(id)) throw new Error('Bad version id');
  const f = R('versions', id, id + '.json');
  if (fs.existsSync(f)) {
    const m = JSON.parse(fs.readFileSync(f, 'utf8'));
    if (m.inheritsFrom) {
      const parent = await meta(m.inheritsFrom);
      return { ...parent, ...m, downloads: m.downloads || parent.downloads,
        assetIndex: m.assetIndex || parent.assetIndex, assets: m.assets || parent.assets,
        libraries: [...(parent.libraries || []), ...(m.libraries || [])] };
    }
    return m;
  }
  const v = (await manifest()).versions.find(x => x.id === id); if (!v) throw new Error('Unknown version ' + id);
  const m = await getJson(v.url); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(m)); return m;
}

async function install(id, send = () => {}) {
  if (isInstalled(id)) return;
  const m = await meta(id), jobs = [], natives = [];
  jobs.push({ u: m.downloads.client.url, d: R('versions', id, id + '.jar'), h: m.downloads.client.sha1 });
  for (const l of m.libraries) {
    if (!allowed(l.rules)) continue;
    const a = l.downloads?.artifact; if (a?.url) jobs.push({ u: a.url, d: R('libraries', a.path), h: a.sha1 });
    const key = l.natives?.windows?.replace('${arch}', '64'), c = key && l.downloads?.classifiers?.[key];   // legacy (<1.19) natives
    if (c) { jobs.push({ u: c.url, d: R('libraries', c.path), h: c.sha1 }); natives.push(R('libraries', c.path)); }
  }
  const idx = await getJson(m.assetIndex.url);
  fs.mkdirSync(R('assets', 'indexes'), { recursive: true });
  fs.writeFileSync(R('assets', 'indexes', m.assetIndex.id + '.json'), JSON.stringify(idx));
  for (const h of new Set(Object.values(idx.objects).map(o => o.hash)))
    jobs.push({ u: `https://resources.download.minecraft.net/${h.slice(0, 2)}/${h}`, d: R('assets', 'objects', h.slice(0, 2), h) });
  let done = 0;
  await pool(jobs, 16, async j => { await fetchFile(j.u, j.d, j.h); if (++done % 20 === 0 || done === jobs.length) send('progress', { text: `Installing ${id}: ${done}/${jobs.length}`, p: done / jobs.length }); });
  const nd = R('versions', id, 'natives'); fs.mkdirSync(nd, { recursive: true });
  for (const n of natives) new AdmZip(n).getEntries().forEach(e => { if (!e.isDirectory && !e.entryName.startsWith('META-INF')) fs.writeFileSync(path.join(nd, path.basename(e.entryName)), e.getData()); });
  fs.writeFileSync(R('versions', id, id + '.ready'), '1');
  send('progress', { text: `Installed ${id}`, p: 0 });
}

const FABRIC_META = 'https://meta.fabricmc.net/v2';
async function loaderList() {
  const [fabricGames, fabricLoaders, forgePromos] = await Promise.all([
    getJson(`${FABRIC_META}/versions/game`), getJson(`${FABRIC_META}/versions/loader`),
    getJson('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json')
  ]);
  const releases = fabricGames.filter(x => x.stable).map(x => x.version);
  const forge = Object.entries(forgePromos.promos || {}).filter(([k]) => k.endsWith('-recommended') || k.endsWith('-latest'))
    .map(([k, v]) => ({ game: k.replace(/-(recommended|latest)$/, ''), version: v, channel: k.endsWith('-recommended') ? 'Recommended' : 'Latest' }));
  return { fabric: releases.map(game => ({ game, loaders: fabricLoaders.slice(0, 8).map(x => x.version) })), forge };
}
async function installLoader(kind, game, loader, send = () => {}) {
  if (!/^[\w.+\-]+$/.test(game) || !/^[\w.+\-]+$/.test(loader)) throw new Error('Bad loader version');
  const id = kind === 'fabric' ? `fabric-loader-${loader}-${game}` : `${game}-forge-${loader}`;
  if (isInstalled(id)) {
    if (kind !== 'fabric') return id;
    try {
      const old = JSON.parse(fs.readFileSync(R('versions', id, `${id}.json`), 'utf8'));
      if ((old.libraries || []).every(l => !l.name || l.downloads?.artifact?.path)) return id;
    } catch {}
    // Older Mamba profiles did not expose Fabric Maven coordinates to the launch classpath.
    fs.rmSync(R('versions', id, `${id}.ready`), { force: true });
  }
  if (kind === 'fabric') {
    const profile = await getJson(`${FABRIC_META}/versions/loader/${encodeURIComponent(game)}/${encodeURIComponent(loader)}/profile/json`);
    await install(game, send);
    let done = 0;
    const libraries = (profile.libraries || []).map(l => {
      const parts = String(l.name || '').split(':');
      if (parts.length < 3) return l;
      const [group, artifact, version, classifier] = parts;
      const rel = [...group.split('.'), artifact, version, `${artifact}-${version}${classifier ? `-${classifier}` : ''}.jar`].join('/');
      return { ...l, downloads: { ...(l.downloads || {}), artifact: { ...(l.downloads?.artifact || {}), path: l.downloads?.artifact?.path || rel, url: l.downloads?.artifact?.url || `${String(l.url || 'https://maven.fabricmc.net').replace(/\/$/, '')}/${rel}` } } };
    });
    profile.libraries = libraries;
    fs.mkdirSync(R('versions', id), { recursive: true });
    fs.writeFileSync(R('versions', id, id + '.json'), JSON.stringify(profile));
    const base = await meta(game);
    for (const l of libraries) if (l.downloads?.artifact?.url && l.downloads.artifact.path) {
      await fetchFile(l.downloads.artifact.url, R('libraries', l.downloads.artifact.path));
      send('progress', { text: `Downloading Fabric libraries: ${++done}/${libraries.length}`, p: done / Math.max(1, libraries.length) });
    }
    if (!base) throw new Error('Base game profile unavailable');
  } else if (kind === 'forge') {
    const forgeId = `${game}-${loader}`;
    const url = `https://maven.minecraftforge.net/net/minecraftforge/forge/${forgeId}/forge-${forgeId}-installer.jar`;
    const installer = R('installers', `forge-${forgeId}-installer.jar`);
    await fetchFile(url, installer);
    const base = await meta(game), javaExe = await javaFor(base, '', send);
    await new Promise((resolve, reject) => {
      const child = spawn(javaExe, ['-jar', installer, '--installClient', JAVA_ROOT], { windowsHide: true });
      child.stdout.on('data', d => send('log', d.toString())); child.stderr.on('data', d => send('log', d.toString()));
      child.once('error', reject); child.once('close', code => code === 0 ? resolve() : reject(new Error(`Forge installer exited with code ${code}`)));
    });
    const generated = R('versions', forgeId, `${forgeId}.json`);
    if (!fs.existsSync(generated)) throw new Error('Forge installer did not create a launch profile');
    const profile = JSON.parse(fs.readFileSync(generated, 'utf8'));
    fs.mkdirSync(R('versions', id), { recursive: true });
    fs.writeFileSync(R('versions', id, id + '.json'), JSON.stringify({ ...profile, id, inheritsFrom: profile.inheritsFrom || game }));
  } else throw new Error('Unknown loader');
  fs.writeFileSync(R('versions', id, id + '.ready'), '1');
  return id;
}

// Java: custom path from Settings, otherwise download the exact runtime this Minecraft version needs.
async function javaFor(m, custom, send) {
  custom = (custom || '').trim();
  if (custom && !['java', 'auto'].includes(custom.toLowerCase())) return custom;
  const comp = m.javaVersion?.component || 'jre-legacy', dir = R('runtime', comp), exe = path.join(dir, 'bin', 'java.exe');
  if (fs.existsSync(path.join(dir, '.ready'))) return exe;
  const plat = { x64: 'windows-x64', arm64: 'windows-arm64', ia32: 'windows-x86' }[process.arch];
  const e = (await getJson(RT_ALL))[plat]?.[comp]?.[0];
  if (!e) throw new Error(`No automatic Java (${comp}) for ${plat}. Install Java and set its path in Settings`);
  const files = Object.entries((await getJson(e.manifest.url)).files).filter(([, f]) => f.type === 'file');
  let done = 0;
  await pool(files, 12, async ([p, f]) => {
    const dest = path.join(dir, p); if (!dest.startsWith(dir + path.sep)) return;
    await fetchFile(f.downloads.raw.url, dest, f.downloads.raw.sha1);
    if (++done % 10 === 0 || done === files.length) send('progress', { text: `Downloading Java (${comp}): ${done}/${files.length}`, p: done / files.length });
  });
  fs.writeFileSync(path.join(dir, '.ready'), '1'); return exe;
}

async function launch(inst, acc, cfg, server, send) {
  const id = inst.version; if (!id) throw new Error('Instance has no version');
  if (id.startsWith('fabric-loader-')) {
    try {
      const profile = JSON.parse(fs.readFileSync(R('versions', id, `${id}.json`), 'utf8'));
      if ((profile.libraries || []).some(l => l.name && !l.downloads?.artifact?.path) && profile.inheritsFrom) {
        const loader = id.slice('fabric-loader-'.length, -(`-${profile.inheritsFrom}`).length);
        await installLoader('fabric', profile.inheritsFrom, loader, send);
      }
    } catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
  await install(id, send);
  const m = await meta(id), gd = gameDir(inst); fs.mkdirSync(gd, { recursive: true });
  const javaExe = await javaFor(m, cfg.javaPath, send);
  // Loader profiles inherit the vanilla game jar; they do not have a client jar of their own.
  const gameJarId = m.inheritsFrom || id;
  const cp = [...m.libraries.filter(l => allowed(l.rules) && l.downloads?.artifact).map(l => R('libraries', l.downloads.artifact.path)), R('versions', gameJarId, `${gameJarId}.jar`)].join(';');
  const V = { auth_player_name: acc.name, auth_uuid: acc.uuid.replace(/-/g, ''), auth_access_token: acc.token || '0', clientid: '0', auth_xuid: '0', user_type: acc.userType || 'legacy', user_properties: '{}', auth_session: '0',
    version_name: id, version_type: m.type, game_directory: gd, assets_root: R('assets'), assets_index_name: m.assetIndex.id, game_assets: R('assets', 'virtual', 'legacy'),
    natives_directory: R('versions', id, 'natives'), launcher_name: 'MambaLauncher', launcher_version: '1.0', classpath: cp, library_directory: R('libraries'), classpath_separator: ';' };
  const sub = s => s.replace(/\$\{(\w+)\}/g, (_, k) => V[k] ?? '');
  const walk = arr => (arr || []).flatMap(a => typeof a === 'string' ? [a] : allowed(a.rules) ? [].concat(a.value) : []);
  let jvm, game;
  if (m.arguments) { jvm = walk(m.arguments.jvm); game = walk(m.arguments.game); }
  else { jvm = ['-Djava.library.path=${natives_directory}', '-cp', '${classpath}']; game = m.minecraftArguments.split(' '); }
  // Fabric's launcher profile can provide JVM flags without Mojang's classpath pair.
  // The loader main class itself lives in the libraries classpath, so add it explicitly.
  if (id.startsWith('fabric-loader-') && !jvm.some(a => a === '-cp' || a === '-classpath')) jvm.unshift('-cp', '${classpath}');
  if (server) game.push('--server', server.host, '--port', String(server.port));
  const user = cfg.jvmArgs.split(/\s+/).filter(a => a.startsWith('-'));   // the unlock flag must come first, otherwise experimental flags (G1NewSizePercent...) kill the JVM
  const gc = cfg.gc === 'g1gc' ? ['-XX:+UseG1GC'] : cfg.gc === 'zgc' ? ['-XX:+UseZGC'] : [];
  const args = [`-Xms${cfg.ramMin}M`, `-Xmx${cfg.ramMax}M`, ...gc, ...(user.length ? ['-XX:+UnlockExperimentalVMOptions'] : []), ...user, ...jvm.map(sub), m.mainClass, ...game.map(sub)];
  send('progress', { text: `Launching ${inst.name}...`, p: 0 });
  if(activeGames.has(inst.id))throw new Error('This Java instance is already running.');
  const c = spawn(javaExe, args, { cwd: gd, windowsHide: true });
  await new Promise((res, rej) => { c.once('spawn', res); c.once('error', e => rej(new Error('Cannot start Java: ' + e.message + ' (set the Java path in Settings)'))); });
  activeGames.set(inst.id,c);
  const log = d => send('log', d.toString()); c.stdout.on('data', log); c.stderr.on('data', log);
  c.on('close', code => {if(activeGames.get(inst.id)===c)activeGames.delete(inst.id);send('exit', { id: inst.id, code });});
}
function stop(id){
  const game=activeGames.get(id);if(!game||game.exitCode!==null)return {stopped:false,message:'This Java instance is not running from the launcher.'};
  if(!game.pid)throw new Error('Could not find the Java process for this instance.');
  try{execFileSync('taskkill',['/PID',String(game.pid),'/T','/F'],{stdio:'ignore'});return {stopped:true};}
  catch{try{game.kill('SIGKILL');return {stopped:true};}catch{throw new Error('Windows could not stop this Java instance. Try closing it from Task Manager.');}}
}
module.exports = { list, install, loaderList, installLoader, launch, stop };
