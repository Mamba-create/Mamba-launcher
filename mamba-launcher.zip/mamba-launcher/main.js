const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const st = require('./src/store'), java = require('./src/java'), be = require('./src/bedrock'), auth = require('./src/auth');
let win;
const send = (c, d) => win && !win.isDestroyed() && win.webContents.send(c, d);
const H = (c, f) => ipcMain.handle(c, (_, ...a) => f(...a));

app.setAppUserModelId('com.mamba.launcher');
app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 1100, height: 700, minWidth: 900, minHeight: 600, frame: false, backgroundColor: '#17191d', icon: path.join(__dirname, 'build', 'icon.png'), title: 'Mamba Launcher',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
  win.on('closed', () => app.quit());
});
app.on('window-all-closed', () => app.quit());

async function play(ed, id, server) {
  const inst = st.getInstance(ed, id);
  if (!inst) throw new Error('Instance not found');
  if (server) {
    if (!/^[\w.\-]{1,253}$/.test(server.host) || !(server.port > 0 && server.port < 65536)) throw new Error('Bad server address');
    server = { host: server.host, port: Number(server.port) };
  }
  if (ed === 'bedrock') await be.launch(inst, server);
  else {
    const c = st.cfg(), acc = c.accounts.find(a => a.id === c.activeAccount);
    if (!acc) throw new Error('Add a Java account first (Accounts tab)');
    let session = { name: acc.name, uuid: acc.uuid, token: '0', userType: 'legacy' };
    if (acc.type === 'microsoft') { send('progress', { text: 'Signing in to Microsoft...', p: 0 }); session = await auth.session(acc, c.settings.msClientId, r => st.setRefresh(acc.id, r)); }
    await java.launch(inst, session, c.settings, server, send);
  }
  st.touch(inst);
}

H('win', a => { if (a === 'focus') { if (!win.isFocused()) win.focus(); win.webContents.focus(); } else if (a === 'min') win.minimize(); else if (a === 'max') win.isMaximized() ? win.unmaximize() : win.maximize(); else if (a === 'close') win.close(); });
H('inst:list', ed => st.listInstances(ed));
H('inst:create', o => st.createInstance(o));
H('inst:delete', (ed, id) => st.deleteInstance(ed, id));
H('inst:folder', (ed, id) => shell.openPath(st.instDir(ed, id)));
H('inst:play', play);
H('versions:list', () => java.list());
H('versions:install', id => java.install(id, send));
H('acc:list', () => st.accountsInfo());
H('acc:add', n => st.addAccount(n));
H('acc:ms-login', async () => st.addMicrosoft(await auth.login(st.cfg().settings.msClientId, send)));
H('acc:ms-cancel', () => auth.cancel());
H('acc:remove', id => st.removeAccount(id));
H('acc:select', id => st.selectAccount(id));
H('set:get', () => st.cfg().settings);
H('set:save', s => st.saveSettings(s));
H('srv:list', () => st.cfg().servers);
H('srv:add', s => st.addServer(s));
H('srv:remove', id => st.removeServer(id));
H('paths', () => st.paths());
