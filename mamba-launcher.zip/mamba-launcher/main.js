const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const st = require('./src/store'), java = require('./src/java'), be = require('./src/bedrock'), auth = require('./src/auth');
const content = require('./src/content');
const packs = require('./src/packs');
let win;
const instanceWindows = new Map();
const send = (c, d) => win && !win.isDestroyed() && win.webContents.send(c, d);
const H = (c, f) => ipcMain.handle(c, (_, ...a) => f(...a));

app.setAppUserModelId('com.mamba.launcher');
app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 1100, height: 700, minWidth: 900, minHeight: 600, frame: false, backgroundColor: '#17191d', icon: path.join(__dirname, 'build', 'icon.png'), title: 'Mamba Launcher',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
  win.on('closed', () => { win = null; });
});
app.on('window-all-closed', () => app.quit());

async function play(ed, id, server) {
  const inst = st.getInstance(ed, id);
  if (!inst) throw new Error('Instance not found');
  if (server) {
    if (!/^[\w.\-]{1,253}$/.test(server.host) || !(server.port > 0 && server.port < 65536)) throw new Error('Bad server address');
    server = { host: server.host, port: Number(server.port) };
  }
  if (ed === 'bedrock') await be.launch(inst, server);
  else {
    const c = st.cfg(), acc = c.accounts.find(a => a.id === c.activeAccount);
    if (!acc) throw new Error('Add a Java account first (Accounts tab)');
    let session = { name: acc.name, uuid: acc.uuid, token: '0', userType: 'legacy' };
    if (acc.type === 'microsoft') { send('progress', { text: 'Signing in to Microsoft...', p: 0 }); session = await auth.session(acc, c.settings.msClientId, r => st.setRefresh(acc.id, r)); }
    const instanceSend = (channel, data) => { if (channel === 'log') st.appendInstanceLog(ed, id, data); send(channel, data); };
    await java.launch(inst, session, { ...c.settings, ...(inst.settings || {}) }, server, instanceSend);
  }
  st.touch(inst);
}

ipcMain.handle('win', (event, action) => {
  const target = BrowserWindow.fromWebContents(event.sender);
  if (!target || target.isDestroyed()) return false;
  if (action === 'focus') { if (!target.isFocused()) target.focus(); target.webContents.focus(); }
  else if (action === 'min') target.minimize();
  else if (action === 'max') target.isMaximized() ? target.unmaximize() : target.maximize();
  else if (action === 'close') target.close();
  return true;
});
H('inst:list', ed => st.listInstances(ed));
H('inst:create', o => st.createInstance(o));
H('inst:clone', (ed,id,name) => { const old=st.getInstance(ed,id);if(!old)throw new Error('Instance not found');return st.createInstance({edition:ed,name,version:old.version}); });
H('inst:delete', (ed, id) => st.deleteInstance(ed, id));
H('inst:folder', (ed, id) => shell.openPath(st.instDir(ed, id)));
H('inst:details', (ed, id) => st.instanceDetails(ed, id));
H('inst:settings', (ed, id, s) => st.saveInstanceSettings(ed, id, s));
H('inst:open-folder', (ed, id, key) => { const d = st.instanceDetails(ed, id); const f = d.folders[key]; return f ? shell.openPath(f.path) : Promise.reject(new Error('Folder not available')); });
H('content:search', (ed,id,source,q,kind,offset) => content.search(ed,id,source,q,st.cfg().settings.curseforgeApiKey,kind,offset));
H('content:versions', (ed,id,source,pid,kind) => content.versions(ed,id,source,pid,st.cfg().settings.curseforgeApiKey,kind));
H('content:install', (ed,id,source,pid,url,name,kind,versionId,metadata) => content.install(ed,id,source,pid,url,name,kind,versionId,st.cfg().settings.curseforgeApiKey,metadata));
H('content:manage', (ed,id,action,kind,name) => { const result=content.manage(ed,id,action,kind,name);send('instance-changed',{edition:ed,id});return result; });
H('content:import', async (ed,id) => {
  if (ed !== 'bedrock') throw new Error('Local pack import is only available for Bedrock.');
  const owner = BrowserWindow.fromWebContents ? BrowserWindow.fromWebContents(win?.webContents) : win;
  const choice = await dialog.showOpenDialog(owner || undefined, {
    title: 'Add Bedrock packs', properties: ['openFile','multiSelections'],
    filters: [{ name: 'Bedrock packs', extensions: ['mcpack','mcaddon','zip'] }]
  });
  if (choice.canceled || !choice.filePaths.length) return { imported: [], errors: [] };
  const result = content.importBedrock(id, choice.filePaths);
  send('instance-changed',{edition:ed,id});
  return result;
});
H('packs:search', (q,game,loader,offset) => packs.search(q,game,loader,offset));
H('packs:versions', (pid,game,loader) => packs.versions(pid,game,loader));
H('packs:install', (pid,vid,name) => packs.install(pid,vid,name));
H('packs:import', async id => {
  const owner=win&&!win.isDestroyed()?win:undefined;
  const choice=await dialog.showOpenDialog(owner,{title:'Import Java modpack',properties:['openFile'],filters:[{name:'Java modpacks',extensions:['mrpack','zip']}]});
  if(choice.canceled||!choice.filePaths.length)return {imported:0,skipped:0,name:''};
  const result=await packs.importIntoInstance(id,choice.filePaths,st.cfg().settings.curseforgeApiKey);
  send('instance-changed',{edition:'java',id});
  return result;
});
H('inst:play', play);
H('inst:stop', (ed,id) => { if(ed==='bedrock')return be.stop();if(ed==='java')return java.stop(id);throw new Error('Unknown game edition.'); });
ipcMain.handle('inst:open-window', (event,ed,id) => {
  const key=`${ed}:${id}`, existing=instanceWindows.get(key);if(existing&&!existing.isDestroyed()){existing.focus();return true;}
  const detail=new BrowserWindow({width:1040,height:760,minWidth:860,minHeight:620,frame:false,backgroundColor:'#17191d',title:`${st.getInstance(ed,id)?.name||'Instance'} — Mamba Launcher`,webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}});
  instanceWindows.set(key,detail);detail.on('closed',()=>instanceWindows.delete(key));detail.setMenuBarVisibility(false);detail.loadFile(path.join(__dirname,'ui','index.html'),{query:{instanceEdition:ed,instanceId:id}});return true;
});
ipcMain.handle('win:self-close',event=>{const w=BrowserWindow.fromWebContents(event.sender);if(w&&w!==win)w.close();});
H('versions:list', () => java.list());
H('versions:install', id => java.install(id, send));
H('loaders:list', () => java.loaderList());
H('loaders:install', (kind, game, loader) => java.installLoader(kind, game, loader, send));
H('acc:list', () => st.accountsInfo());
H('acc:add', n => st.addAccount(n));
H('acc:ms-login', async () => st.addMicrosoft(await auth.login(st.cfg().settings.msClientId, send)));
H('acc:ms-cancel', () => auth.cancel());
H('acc:remove', id => st.removeAccount(id));
H('acc:select', id => st.selectAccount(id));
H('set:get', () => st.cfg().settings);
H('set:save', s => st.saveSettings(s));
H('srv:list', () => st.cfg().servers);
H('srv:add', s => st.addServer(s));
H('srv:remove', id => st.removeServer(id));
H('paths', () => st.paths());
