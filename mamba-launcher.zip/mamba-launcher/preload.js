const { contextBridge, ipcRenderer } = require('electron');
const INVOKE = new Set(['win','win:self-close','inst:list','inst:create','inst:clone','inst:open-window','inst:delete','inst:folder','inst:details','inst:settings','inst:open-folder','content:search','content:versions','content:install','content:manage','content:import','packs:search','packs:versions','packs:install','packs:import','inst:play','inst:stop','versions:list','versions:install','loaders:list','loaders:install',
  'acc:list','acc:add','acc:remove','acc:select','acc:ms-login','acc:ms-cancel','set:get','set:save','srv:list','srv:add','srv:remove','paths']);
const ON = new Set(['progress', 'log', 'exit', 'msdevice','instance-changed']);
contextBridge.exposeInMainWorld('api', {
  invoke: (c, ...a) => INVOKE.has(c) ? ipcRenderer.invoke(c, ...a) : Promise.reject(new Error('blocked channel')),
  on: (c, f) => { if (ON.has(c)) ipcRenderer.on(c, (_, d) => f(d)); }
});
