const { contextBridge, ipcRenderer } = require('electron');
const INVOKE = new Set(['win','inst:list','inst:create','inst:delete','inst:folder','inst:play','versions:list','versions:install',
  'acc:list','acc:add','acc:remove','acc:select','acc:ms-login','acc:ms-cancel','set:get','set:save','srv:list','srv:add','srv:remove','paths']);
const ON = new Set(['progress', 'log', 'exit', 'msdevice']);
contextBridge.exposeInMainWorld('api', {
  invoke: (c, ...a) => INVOKE.has(c) ? ipcRenderer.invoke(c, ...a) : Promise.reject(new Error('blocked channel')),
  on: (c, f) => { if (ON.has(c)) ipcRenderer.on(c, (_, d) => f(d)); }
});
