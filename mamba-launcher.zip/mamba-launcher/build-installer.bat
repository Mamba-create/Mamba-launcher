@echo off
cd /d "%~dp0"
call npm install || (echo npm install failed & pause & exit /b 1)
call npm run dist || (echo Build failed. If you see a symbolic link error: enable Windows Developer Mode or run this file as administrator & pause & exit /b 1)
explorer dist
