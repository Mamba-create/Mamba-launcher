@echo off
cd /d "%~dp0"
if not exist node_modules\electron\dist\electron.exe (
  echo First run: installing dependencies, please wait...
  call npm install || (echo npm install failed & pause & exit /b 1)
)
start "" "node_modules\electron\dist\electron.exe" .
